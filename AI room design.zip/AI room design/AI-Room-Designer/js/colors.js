/* =========================================================
   AI ROOM DESIGNER
   COLORS MODULE
========================================================= */


/* =========================================================
   COLOR PALETTE DATA
========================================================= */

const colorPalettes = {

    modern: {

        name: "Modern Tech",

        description:
            "Clean neutrals with a technical cyan accent.",

        wall: "#F4F4F0",

        floor: "#D9D9D2",

        furniture: "#263238",

        accent: "#29D8FF"

    },


    minimal: {

        name: "Minimal Neutral",

        description:
            "Soft neutral tones for a calm interior.",

        wall: "#FFFFFF",

        floor: "#E8E5DF",

        furniture: "#A9A39A",

        accent: "#44403C"

    },


    japanese: {

        name: "Japanese Calm",

        description:
            "Natural earthy tones inspired by Japanese interiors.",

        wall: "#E8E1D5",

        floor: "#B8A98A",

        furniture: "#6B6254",

        accent: "#26332D"

    },


    scandinavian: {

        name: "Scandinavian",

        description:
            "Light natural colors with subtle green accents.",

        wall: "#F7F5EF",

        floor: "#D8D0C3",

        furniture: "#A7B3B0",

        accent: "#3E514A"

    },


    luxury: {

        name: "Luxury Warm",

        description:
            "Warm neutrals with elegant metallic-inspired accents.",

        wall: "#F1ECE3",

        floor: "#B7A78C",

        furniture: "#3B3530",

        accent: "#B08D57"

    },


    cool: {

        name: "Cool Blue",

        description:
            "Fresh blue-grey tones for a modern atmosphere.",

        wall: "#EAF4F8",

        floor: "#BFD7E0",

        furniture: "#587783",

        accent: "#214B5A"

    }

};


/* =========================================================
   CURRENT STATE
========================================================= */

let selectedPalette = "modern";


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Colors module initialized."
        );


        loadRoomData();

        loadSavedPalette();

        initializePaletteSelection();

        updatePalettePreview();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const roomData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (roomData) {

        try {

            const data =
                JSON.parse(roomData);


            setText(
                "roomType",
                data.roomType ||
                "Not available"
            );


            setText(
                "roomArea",
                formatNumber(data.area)
            );


            setText(
                "roomStyle",
                capitalize(
                    data.style ||
                    "modern"
                )
            );

        } catch (error) {

            console.error(
                "Room data error:",
                error
            );

        }

    }


    loadFurnitureCount();

}


/* =========================================================
   LOAD FURNITURE COUNT
========================================================= */

function loadFurnitureCount() {

    const furnitureData =
        localStorage.getItem(
            "aiFurnitureData"
        );


    if (!furnitureData) {

        setText(
            "furnitureCount",
            "0"
        );

        return;

    }


    try {

        const data =
            JSON.parse(
                furnitureData
            );


        const count =
            Array.isArray(data.selected)
                ? data.selected.length
                : 0;


        setText(
            "furnitureCount",
            count
        );

    } catch (error) {

        console.error(
            "Furniture data error:",
            error
        );

    }

}


/* =========================================================
   LOAD SAVED PALETTE
========================================================= */

function loadSavedPalette() {

    const saved =
        localStorage.getItem(
            "aiColorData"
        );


    if (!saved) {

        return;

    }


    try {

        const data =
            JSON.parse(saved);


        if (
            data.palette &&
            colorPalettes[data.palette]
        ) {

            selectedPalette =
                data.palette;

        }

    } catch (error) {

        console.error(
            "Color data error:",
            error
        );

    }

}


/* =========================================================
   PALETTE SELECTION
========================================================= */

function initializePaletteSelection() {

    const cards =
        document.querySelectorAll(
            ".palette-card"
        );


    cards.forEach(
        card => {

            card.addEventListener(
                "click",
                () => {

                    const palette =
                        card.dataset.palette;


                    if (
                        !colorPalettes[palette]
                    ) {

                        return;

                    }


                    selectedPalette =
                        palette;


                    cards.forEach(
                        item =>
                            item.classList.remove(
                                "active"
                            )
                    );


                    card.classList.add(
                        "active"
                    );


                    updatePalettePreview();

                    saveColorData();

                }
            );

        }
    );

}


/* =========================================================
   UPDATE PALETTE PREVIEW
========================================================= */

function updatePalettePreview() {

    const palette =
        colorPalettes[
            selectedPalette
        ];


    if (!palette) {

        return;

    }


    setText(
        "selectedPaletteName",
        palette.name
    );


    setText(
        "selectedPaletteDescription",
        palette.description
    );


    setText(
        "wallColor",
        palette.wall
    );


    setText(
        "floorColor",
        palette.floor
    );


    setText(
        "furnitureColor",
        palette.furniture
    );


    setText(
        "accentColor",
        palette.accent
    );


    setBackground(
        "wallSwatch",
        palette.wall
    );


    setBackground(
        "floorSwatch",
        palette.floor
    );


    setBackground(
        "furnitureSwatch",
        palette.furniture
    );


    setBackground(
        "accentSwatch",
        palette.accent
    );


    updateRoomPreview(
        palette
    );


    updateActiveCard();

}


/* =========================================================
   ACTIVE CARD
========================================================= */

function updateActiveCard() {

    const cards =
        document.querySelectorAll(
            ".palette-card"
        );


    cards.forEach(
        card => {

            card.classList.toggle(
                "active",
                card.dataset.palette ===
                selectedPalette
            );

        }
    );

}


/* =========================================================
   ROOM PREVIEW
========================================================= */

function updateRoomPreview(
    palette
) {

    const preview =
        document.getElementById(
            "roomPreview"
        );


    if (!preview) {

        return;

    }


    const wall =
        preview.querySelector(
            ".preview-wall"
        );


    const floor =
        preview.querySelector(
            ".preview-floor"
        );


    const sofa =
        preview.querySelector(
            ".preview-sofa"
        );


    const picture =
        preview.querySelector(
            ".preview-picture"
        );


    const ceiling =
        preview.querySelector(
            ".preview-ceiling"
        );


    if (wall) {

        wall.style.background =
            palette.wall;

    }


    if (floor) {

        floor.style.background =
            palette.floor;

    }


    if (sofa) {

        sofa.style.background =
            palette.furniture;

    }


    if (picture) {

        picture.style.background =
            palette.accent;

    }


    if (ceiling) {

        ceiling.style.background =
            lightenColor(
                palette.wall,
                8
            );

    }

}


/* =========================================================
   SAVE COLOR DATA
========================================================= */

function saveColorData() {

    const palette =
        colorPalettes[
            selectedPalette
        ];


    if (!palette) {

        return;

    }


    const colorData = {

        palette:
            selectedPalette,

        name:
            palette.name,

        wall:
            palette.wall,

        floor:
            palette.floor,

        furniture:
            palette.furniture,

        accent:
            palette.accent

    };


    localStorage.setItem(
        "aiColorData",
        JSON.stringify(
            colorData
        )
    );


    console.log(
        "Color data saved:",
        colorData
    );

}


/* =========================================================
   HELPERS
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


function setBackground(
    id,
    color
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.style.background =
            color;

    }

}


function formatNumber(
    value
) {

    const number =
        Number(value);


    if (!Number.isFinite(number)) {

        return "0";

    }


    return number.toFixed(2);

}


function capitalize(
    value
) {

    if (!value) {

        return "";

    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


/* =========================================================
   LIGHTEN COLOR
========================================================= */

function lightenColor(
    hex,
    amount
) {

    let color =
        hex.replace(
            "#",
            ""
        );


    if (color.length !== 6) {

        return hex;

    }


    const number =
        parseInt(
            color,
            16
        );


    let r =
        (number >> 16) + amount;

    let g =
        ((number >> 8) & 0x00FF) +
        amount;

    let b =
        (number & 0x0000FF) +
        amount;


    r =
        Math.min(
            255,
            Math.max(0,r)
        );


    g =
        Math.min(
            255,
            Math.max(0,g)
        );


    b =
        Math.min(
            255,
            Math.max(0,b)
        );


    return (
        "#" +
        (r << 16 | g << 8 | b)
            .toString(16)
            .padStart(6,"0")
    );

}


/* =========================================================
   DEBUG ACCESS
========================================================= */

window.AIRoomColors = {

    colorPalettes,

    getSelectedPalette:
        () =>
            colorPalettes[
                selectedPalette
            ],

    saveColorData

};