
const contactForm = document.getElementById("contactForm");
const contactStatus = document.getElementById("contactStatus");

contactForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = document.getElementById("contactName").value.trim();
    const email = document.getElementById("contactEmail").value.trim();
    const subject = document.getElementById("contactSubject").value.trim();
    const message = document.getElementById("contactMessage").value.trim();

    if (!name || !email || !subject || !message) {
        contactStatus.textContent = "Please complete all fields.";
        return;
    }

    contactStatus.textContent =
        "Form validated successfully. Message sending will be connected to the backend later.";

    contactForm.reset();
});

