/* =========================================================
   AI ROOM DESIGNER
   ANALYSIS PAGE JAVASCRIPT
========================================================= */


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Analysis page initialized."
        );


        loadRoomData();

        setupAnalysis();

    }
);


/* =========================================================
   LOAD DATA FROM HOME PAGE
========================================================= */

function loadRoomData() {

    /*
       Step 4 stores the room information
       in memory while index.html is open.

       localStorage allows us to keep the
       calculated information when moving
       between pages.
    */


    const savedData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedData) {

        console.log(
            "No saved room data found."
        );

        return;

    }


    try {

        const data =
            JSON.parse(
                savedData
            );


        updatePage(
            data
        );


    } catch (error) {

        console.error(
            "Could not load room data:",
            error
        );

    }

}


/* =========================================================
   UPDATE PAGE
========================================================= */

function updatePage(data) {

    setText(
        "roomType",
        data.roomType || "Not calculated"
    );


    setText(
        "roomArea",
        formatNumber(data.area)
    );


    setText(
        "roomVolume",
        formatNumber(data.volume)
    );


    setText(
        "roomStyle",
        capitalize(
            data.style || "modern"
        )
    );


    setText(
        "lengthValue",
        formatNumber(data.length)
    );


    setText(
        "breadthValue",
        formatNumber(data.breadth)
    );


    setText(
        "heightValue",
        formatNumber(data.height)
    );


    generateRecommendations(
        data
    );


    generateAnalysis(
        data
    );


    setStatus(
        "ANALYSIS COMPLETE"
    );

}


/* =========================================================
   AI ANALYSIS
========================================================= */

function generateAnalysis(data) {

    const content =
        document.getElementById(
            "analysisContent"
        );


    if (!content) {

        return;

    }


    const style =
        capitalize(
            data.style || "modern"
        );


    const area =
        Number(data.area) || 0;


    const roomType =
        data.roomType ||
        determineRoomType(area);


    let spaceMessage;


    if (area < 80) {

        spaceMessage =
            "The room has a compact footprint. Furniture should be carefully selected to preserve comfortable movement.";

    }

    else if (area < 150) {

        spaceMessage =
            "The room provides a balanced amount of space for essential furniture and functional design elements.";

    }

    else if (area < 250) {

        spaceMessage =
            "The room provides generous space for multiple furniture zones and additional decorative elements.";

    }

    else {

        spaceMessage =
            "The room provides extensive space and can support multiple functional zones.";

    }


    content.innerHTML = `

        <div class="generated-analysis">

            <div class="analysis-summary">

                <div class="summary-icon">
                    ✓
                </div>

                <div>

                    <span>
                        AI ANALYSIS COMPLETE
                    </span>

                    <h3>
                        ${style} design profile detected
                    </h3>

                </div>

            </div>


            <div class="analysis-text">

                <p>
                    Your room is classified as
                    <strong>${roomType}</strong>
                    with a floor area of
                    <strong>${formatNumber(area)} sq.ft</strong>.
                </p>


                <p>
                    The selected design direction is
                    <strong>${style}</strong>.
                    ${spaceMessage}
                </p>


                <p>
                    The following project stages will
                    use this analysis to recommend
                    furniture, colors, blueprint
                    arrangements and lighting.
                </p>

            </div>


            <div class="analysis-metrics">

                <div>

                    <span>
                        AREA
                    </span>

                    <strong>
                        ${formatNumber(area)}
                    </strong>

                </div>


                <div>

                    <span>
                        STYLE
                    </span>

                    <strong>
                        ${style}
                    </strong>

                </div>


                <div>

                    <span>
                        TYPE
                    </span>

                    <strong>
                        ${roomType}
                    </strong>

                </div>

            </div>

        </div>

    `;


    addGeneratedAnalysisStyles();

}


/* =========================================================
   RECOMMENDATIONS
========================================================= */

function generateRecommendations(data) {

    const style =
        (
            data.style ||
            "modern"
        ).toLowerCase();


    const furniture =
        document.getElementById(
            "furnitureRecommendation"
        );


    const colors =
        document.getElementById(
            "colorRecommendation"
        );


    const lighting =
        document.getElementById(
            "lightingRecommendation"
        );


    const recommendations = {

        modern: {

            furniture:
                "Choose clean-lined sofas, modular storage and simple geometric furniture.",

            colors:
                "Use neutral shades with one controlled accent color.",

            lighting:
                "Use recessed LEDs, task lighting and subtle accent lights."

        },


        luxury: {

            furniture:
                "Use elegant statement furniture with balanced proportions and premium finishes.",

            colors:
                "Combine warm neutrals with deeper accent tones.",

            lighting:
                "Use layered warm lighting with decorative fixtures."

        },


        minimal: {

            furniture:
                "Keep only essential furniture and maintain clear walking paths.",

            colors:
                "Use a restrained neutral palette with minimal contrast.",

            lighting:
                "Use simple concealed lighting with strong natural light."

        },


        japanese: {

            furniture:
                "Prefer low-profile furniture and natural material finishes.",

            colors:
                "Use calm earth-inspired neutral colors.",

            lighting:
                "Use soft indirect lighting and maximize natural light."

        },


        scandinavian: {

            furniture:
                "Choose functional furniture with simple forms and natural textures.",

            colors:
                "Use light neutrals with subtle natural accent colors.",

            lighting:
                "Maximize daylight and use warm ambient lighting."

        }

    };


    const selected =
        recommendations[style] ||
        recommendations.modern;


    if (furniture) {

        furniture.textContent =
            selected.furniture;

    }


    if (colors) {

        colors.textContent =
            selected.colors;

    }


    if (lighting) {

        lighting.textContent =
            selected.lighting;

    }

}


/* =========================================================
   STATUS
========================================================= */

function setStatus(text) {

    const status =
        document.getElementById(
            "aiStatus"
        );


    if (status) {

        status.textContent =
            text;

    }

}


/* =========================================================
   HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(id);


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   NUMBER FORMAT
========================================================= */

function formatNumber(value) {

    const number =
        Number(value);


    if (!Number.isFinite(number)) {

        return "0";

    }


    return number.toFixed(2);

}


/* =========================================================
   ROOM TYPE
========================================================= */

function determineRoomType(
    area
) {

    if (area < 80) {

        return "Small Room";

    }


    if (area < 150) {

        return "Medium Room";

    }


    if (area < 250) {

        return "Large Room";

    }


    return "Spacious Room";

}


/* =========================================================
   CAPITALIZE
========================================================= */

function capitalize(value) {

    if (!value) {

        return "";

    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


/* =========================================================
   ANALYSIS STYLES
========================================================= */

function addGeneratedAnalysisStyles() {

    if (
        document.getElementById(
            "generatedAnalysisStyles"
        )
    ) {

        return;

    }


    const style =
        document.createElement(
            "style"
        );


    style.id =
        "generatedAnalysisStyles";


    style.textContent = `

        .generated-analysis {

            width: 100%;

        }


        .analysis-summary {

            display: flex;

            align-items: center;

            gap: 15px;

            margin-bottom: 22px;

        }


        .summary-icon {

            width: 42px;

            height: 42px;

            display: grid;

            place-items: center;

            border:
                1px solid
                var(--cyan);

            color:
                var(--cyan);

            font-size: 18px;

        }


        .analysis-summary span {

            color:
                var(--cyan);

            font-size: 8px;

            letter-spacing: 2px;

        }


        .analysis-summary h3 {

            font-size: 16px;

            margin-top: 5px;

        }


        .analysis-text {

            border-left:
                2px solid
                var(--cyan);

            padding-left: 18px;

        }


        .analysis-text p {

            color:
                var(--muted);

            font-size: 12px;

            line-height: 1.8;

            margin-bottom: 10px;

        }


        .analysis-text strong {

            color:
                var(--text);

        }


        .analysis-metrics {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 10px;

            margin-top: 22px;

        }


        .analysis-metrics div {

            padding: 12px;

            border:
                1px solid
                var(--border);

        }


        .analysis-metrics span {

            display: block;

            color:
                var(--muted);

            font-size: 8px;

            letter-spacing: 1px;

            margin-bottom: 5px;

        }


        .analysis-metrics strong {

            color:
                var(--cyan);

            font-size: 12px;

        }


        @media (max-width: 600px) {

            .analysis-metrics {

                grid-template-columns:
                    1fr;

            }

        }

    `;


    document.head.appendChild(
        style
    );

}


/* =========================================================
   SETUP
========================================================= */

function setupAnalysis() {

    /*
       Save a sample room state if the page
       is opened directly for the first time.
    */

    const existing =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!existing) {

        console.log(
            "Analysis page is waiting for Home page data."
        );

    }

}