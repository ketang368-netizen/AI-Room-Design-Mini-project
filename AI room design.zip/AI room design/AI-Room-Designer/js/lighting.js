/* =========================================================
   AI ROOM DESIGNER
   LIGHTING MODULE
========================================================= */


/* =========================================================
   DEFAULT DATA
========================================================= */

let roomData = {

    roomType: "Living Room",

    length: 12,

    breadth: 10,

    height: 10,

    area: 120

};


let lightingData = {

    ambient: true,

    task: true,

    accent: true,

    intensity: 70,

    temperature: "neutral",

    temperatureValue: 4000

};


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Lighting module initialized."
        );


        loadRoomData();

        loadLightingData();

        updateRoomSummary();

        initializeLightingControls();

        updateLightingPreview();

        updateRecommendation();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const savedData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedData) {

        return;

    }


    try {

        const data =
            JSON.parse(
                savedData
            );


        roomData = {

            ...roomData,

            ...data

        };


        roomData.length =
            Number(
                data.length ||
                data.roomLength ||
                roomData.length
            );


        roomData.breadth =
            Number(
                data.breadth ||
                data.roomBreadth ||
                roomData.breadth
            );


        roomData.height =
            Number(
                data.height ||
                data.roomHeight ||
                roomData.height
            );


        roomData.area =
            roomData.length *
            roomData.breadth;


    } catch (error) {

        console.error(
            "Room data could not be loaded:",
            error
        );

    }

}


/* =========================================================
   LOAD LIGHTING DATA
========================================================= */

function loadLightingData() {

    const savedData =
        localStorage.getItem(
            "aiLightingData"
        );


    if (!savedData) {

        return;

    }


    try {

        lightingData = {

            ...lightingData,

            ...JSON.parse(
                savedData
            )

        };

    } catch (error) {

        console.error(
            "Lighting data could not be loaded:",
            error
        );

    }

}


/* =========================================================
   ROOM SUMMARY
========================================================= */

function updateRoomSummary() {

    setText(
        "roomType",
        roomData.roomType ||
        "Room"
    );


    const area =
        roomData.length *
        roomData.breadth;


    roomData.area =
        area;


    setText(
        "roomArea",
        area.toFixed(2)
    );


    updateRecommendedLumens();

}


/* =========================================================
   LUMEN CALCULATION
========================================================= */

function updateRecommendedLumens() {

    /*
       Basic frontend estimation:

       Living room:
       approximately 15 lumens / sq.ft

       This is a simplified project simulation.
    */

    const baseLumens =
        roomData.area *
        15;


    const intensityFactor =
        lightingData.intensity /
        70;


    const lumens =
        baseLumens *
        intensityFactor;


    setText(
        "recommendedLumens",
        Math.round(
            lumens
        ) +
        " lm"
    );

}


/* =========================================================
   INITIALIZE CONTROLS
========================================================= */

function initializeLightingControls() {

    /*
       Ambient
    */

    const ambientToggle =
        document.getElementById(
            "ambientToggle"
        );


    if (ambientToggle) {

        ambientToggle.addEventListener(
            "click",
            () => {

                lightingData.ambient =
                    !lightingData.ambient;


                updateToggle(
                    ambientToggle,
                    lightingData.ambient,
                    "ambientState"
                );


                updateLightingPreview();

                updateRecommendation();

                saveLightingData();

            }
        );

    }


    /*
       Task
    */

    const taskToggle =
        document.getElementById(
            "taskToggle"
        );


    if (taskToggle) {

        taskToggle.addEventListener(
            "click",
            () => {

                lightingData.task =
                    !lightingData.task;


                updateToggle(
                    taskToggle,
                    lightingData.task,
                    "taskState"
                );


                updateLightingPreview();

                updateRecommendation();

                saveLightingData();

            }
        );

    }


    /*
       Accent
    */

    const accentToggle =
        document.getElementById(
            "accentToggle"
        );


    if (accentToggle) {

        accentToggle.addEventListener(
            "click",
            () => {

                lightingData.accent =
                    !lightingData.accent;


                updateToggle(
                    accentToggle,
                    lightingData.accent,
                    "accentState"
                );


                updateLightingPreview();

                updateRecommendation();

                saveLightingData();

            }
        );

    }


    /*
       Intensity slider
    */

    const slider =
        document.getElementById(
            "intensitySlider"
        );


    if (slider) {

        slider.value =
            lightingData.intensity;


        slider.addEventListener(
            "input",
            () => {

                lightingData.intensity =
                    Number(
                        slider.value
                    );


                setText(
                    "intensityValue",
                    lightingData.intensity +
                    "%"
                );


                updateLightingPreview();

                updateRecommendedLumens();

                updateRecommendation();

                saveLightingData();

            }
        );

    }


    /*
       Temperature buttons
    */

    const temperatureButtons =
        document.querySelectorAll(
            ".temperature-button"
        );


    temperatureButtons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const temperature =
                        button.dataset.temperature;


                    lightingData.temperature =
                        temperature;


                    if (
                        temperature ===
                        "warm"
                    ) {

                        lightingData.temperatureValue =
                            2700;

                    }

                    else if (
                        temperature ===
                        "cool"
                    ) {

                        lightingData.temperatureValue =
                            6500;

                    }

                    else {

                        lightingData.temperatureValue =
                            4000;

                    }


                    temperatureButtons.forEach(
                        item => {

                            item.classList.remove(
                                "active"
                            );

                        }
                    );


                    button.classList.add(
                        "active"
                    );


                    setText(
                        "temperatureLabel",
                        lightingData.temperatureValue +
                        "K"
                    );


                    updateLightingPreview();

                    updateRecommendation();

                    saveLightingData();

                }
            );

        }
    );


    /*
       Restore toggle states
    */

    updateToggle(
        ambientToggle,
        lightingData.ambient,
        "ambientState"
    );


    updateToggle(
        taskToggle,
        lightingData.task,
        "taskState"
    );


    updateToggle(
        accentToggle,
        lightingData.accent,
        "accentState"
    );


    /*
       Restore intensity
    */

    if (slider) {

        setText(
            "intensityValue",
            lightingData.intensity +
            "%"
        );

    }


    /*
       Restore temperature
    */

    restoreTemperature();

}


/* =========================================================
   TOGGLE UPDATE
========================================================= */

function updateToggle(
    button,
    state,
    stateId
) {

    if (!button) {

        return;

    }


    button.textContent =
        state
            ? "ON"
            : "OFF";


    button.classList.toggle(
        "active",
        state
    );


    setText(
        stateId,
        state
            ? "ON"
            : "OFF"
    );


    const stateElement =
        document.getElementById(
            stateId
        );


    if (stateElement) {

        stateElement.style.color =
            state
                ? "#38e89b"
                : "#7895aa";

    }

}


/* =========================================================
   RESTORE TEMPERATURE
========================================================= */

function restoreTemperature() {

    const buttons =
        document.querySelectorAll(
            ".temperature-button"
        );


    buttons.forEach(
        button => {

            button.classList.toggle(
                "active",
                button.dataset.temperature ===
                lightingData.temperature
            );

        }
    );


    setText(
        "temperatureLabel",
        lightingData.temperatureValue +
        "K"
    );

}


/* =========================================================
   LIGHTING PREVIEW
========================================================= */

function updateLightingPreview() {

    const preview =
        document.getElementById(
            "roomPreview"
        );


    const ceiling =
        document.getElementById(
            "ceilingLight"
        );


    const floorLamp =
        document.getElementById(
            "floorLamp"
        );


    const accent =
        document.getElementById(
            "accentLight"
        );


    if (
        !preview ||
        !ceiling ||
        !floorLamp ||
        !accent
    ) {

        return;

    }


    /*
       Intensity
    */

    const intensity =
        lightingData.intensity /
        100;


    /*
       Ambient lighting
    */

    if (
        lightingData.ambient
    ) {

        ceiling.style.opacity =
            intensity;

        ceiling.style.boxShadow =
            `0 0 ${30 + intensity * 40}px
             rgba(255,240,170,${.3 + intensity * .4})`;

    }

    else {

        ceiling.style.opacity =
            0;

    }


    /*
       Task lighting
    */

    floorLamp.style.opacity =
        lightingData.task
            ? intensity
            : 0;


    /*
       Accent lighting
    */

    accent.style.opacity =
        lightingData.accent
            ? intensity
            : 0;


    /*
       Temperature
    */

    applyTemperature(
        preview
    );


    /*
       Overall brightness
    */

    const brightness =
        .65 +
        (
            lightingData.intensity /
            100
        ) *
        .45;


    preview.style.filter =
        `brightness(${brightness})`;


    updateCurrentMode();

}


/* =========================================================
   TEMPERATURE
========================================================= */

function applyTemperature(
    preview
) {

    if (
        lightingData.temperature ===
        "warm"
    ) {

        preview.style.background =
            `
            radial-gradient(
                circle at 50% 20%,
                rgba(255,180,80,.35),
                transparent 50%
            ),
            #201812
            `;

    }

    else if (
        lightingData.temperature ===
        "cool"
    ) {

        preview.style.background =
            `
            radial-gradient(
                circle at 50% 20%,
                rgba(80,190,255,.30),
                transparent 50%
            ),
            #101d2b
            `;

    }

    else {

        preview.style.background =
            `
            radial-gradient(
                circle at 50% 20%,
                rgba(255,245,200,.20),
                transparent 50%
            ),
            #101c27
            `;

    }

}


/* =========================================================
   CURRENT MODE
========================================================= */

function updateCurrentMode() {

    let mode =
        "Balanced";


    const ambient =
        lightingData.ambient;


    const task =
        lightingData.task;


    const accent =
        lightingData.accent;


    if (
        ambient &&
        task &&
        accent
    ) {

        mode =
            "Balanced";

    }

    else if (
        ambient &&
        task
    ) {

        mode =
            "Functional";

    }

    else if (
        ambient &&
        accent
    ) {

        mode =
            "Ambient + Accent";

    }

    else if (
        ambient
    ) {

        mode =
            "Ambient Only";

    }

    else if (
        task
    ) {

        mode =
            "Task Only";

    }

    else if (
        accent
    ) {

        mode =
            "Accent Only";

    }

    else {

        mode =
            "Minimal";

    }


    setText(
        "currentMode",
        mode
    );

}


/* =========================================================
   AI RECOMMENDATION
========================================================= */

function updateRecommendation() {

    let title =
        "Balanced Room Lighting";


    let text =
        "A balanced combination of ambient, task and accent lighting is recommended for this room.";


    let score = 92;


    /*
       All lighting types
    */

    if (
        lightingData.ambient &&
        lightingData.task &&
        lightingData.accent
    ) {

        title =
            "Balanced Room Lighting";


        text =
            "Ambient lighting provides general illumination, task lighting supports focused activities, and accent lighting adds visual depth to the room.";


        score =
            92;

    }


    /*
       Ambient + task
    */

    else if (
        lightingData.ambient &&
        lightingData.task
    ) {

        title =
            "Functional Lighting";


        text =
            "Ambient and task lighting provide good everyday illumination. Adding a small amount of accent lighting could improve the visual atmosphere.";


        score =
            85;

    }


    /*
       Ambient only
    */

    else if (
        lightingData.ambient
    ) {

        title =
            "General Lighting";


        text =
            "Ambient lighting provides basic room illumination. Task lights are recommended near desks, reading areas or work zones.";


        score =
            72;

    }


    /*
       Task only
    */

    else if (
        lightingData.task
    ) {

        title =
            "Focused Lighting";


        text =
            "Task lighting is useful for focused activities but is not sufficient as the only lighting source for most rooms.";


        score =
            65;

    }


    /*
       Accent only
    */

    else if (
        lightingData.accent
    ) {

        title =
            "Decorative Lighting";


        text =
            "Accent lighting can create atmosphere, but general room illumination should be added for practical use.";


        score =
            55;

    }


    /*
       No lighting
    */

    else {

        title =
            "Lighting Required";


        text =
            "Enable at least ambient lighting to provide basic illumination for the room.";


        score =
            30;

    }


    /*
       Intensity adjustment
    */

    if (
        lightingData.intensity >=
        85
    ) {

        text +=
            " The current intensity is high and is suitable for bright environments.";

    }

    else if (
        lightingData.intensity <=
        35
    ) {

        text +=
            " The current intensity is low and may be better suited for a relaxing atmosphere.";

    }


    setText(
        "recommendationTitle",
        title
    );


    setText(
        "recommendationText",
        text
    );


    setText(
        "lightingScore",
        score
    );

}


/* =========================================================
   SAVE DATA
========================================================= */

function saveLightingData() {

    localStorage.setItem(
        "aiLightingData",
        JSON.stringify(
            lightingData
        )
    );

}


/* =========================================================
   TEXT HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   DEBUG ACCESS
========================================================= */

window.AIRoomLighting = {

    roomData,

    lightingData,

    updateLightingPreview,

    updateRecommendation

};