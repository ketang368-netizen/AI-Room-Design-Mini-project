/* =========================================================
   AI ROOM DESIGNER
   DOWNLOAD / FINAL MODULE
========================================================= */


/* =========================================================
   DEFAULT DATA
========================================================= */

let roomData = {

    roomType: "Living Room",

    length: 12,

    breadth: 10,

    height: 10,

    area: 120,

    style: "Modern"

};


let budgetData = {

    level: "standard",

    total: 0,

    contingency: 0

};


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Final download module initialized."
        );


        loadRoomData();

        loadBudgetData();

        updateSummary();

        initializeButtons();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const savedData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedData) {

        return;

    }


    try {

        const data =
            JSON.parse(
                savedData
            );


        roomData = {

            ...roomData,

            ...data

        };


        roomData.length =
            Number(
                data.length ||
                data.roomLength ||
                roomData.length
            );


        roomData.breadth =
            Number(
                data.breadth ||
                data.roomBreadth ||
                roomData.breadth
            );


        roomData.height =
            Number(
                data.height ||
                data.roomHeight ||
                roomData.height
            );


        roomData.area =
            roomData.length *
            roomData.breadth;


        /*
           Different pages may save the style
           under different names.
        */

        roomData.style =
            data.style ||
            data.roomStyle ||
            data.aiStyle ||
            roomData.style;

    }

    catch (error) {

        console.error(
            "Unable to load room data:",
            error
        );

    }

}


/* =========================================================
   LOAD BUDGET DATA
========================================================= */

function loadBudgetData() {

    const savedData =
        localStorage.getItem(
            "aiBudgetData"
        );


    if (!savedData) {

        return;

    }


    try {

        budgetData = {

            ...budgetData,

            ...JSON.parse(
                savedData
            )

        };

    }

    catch (error) {

        console.error(
            "Unable to load budget data:",
            error
        );

    }

}


/* =========================================================
   UPDATE SUMMARY
========================================================= */

function updateSummary() {

    const area =
        roomData.length *
        roomData.breadth;


    roomData.area =
        area;


    setText(
        "summaryRoomType",

        roomData.roomType ||
        "Room"
    );


    setText(
        "summaryArea",

        area.toFixed(0)
    );


    setText(
        "summaryDimensions",

        `${roomData.length} × ${roomData.breadth} × ${roomData.height} ft`
    );


    setText(
        "summaryStyle",

        formatStyle(
            roomData.style
        )
    );


    /*
       Budget
    */

    setText(
        "finalBudget",

        formatINR(
            Number(
                budgetData.total ||
                0
            )
        )
    );


    setText(
        "finalBudgetLevel",

        formatBudgetLevel(
            budgetData.level
        )
    );


    const costPerSqft =
        area > 0
            ? Number(
                budgetData.total ||
                0
            ) / area
            : 0;


    setText(
        "finalCostPerSqft",

        formatINR(
            costPerSqft
        )
    );


    /*
       AI recommendation
    */

    updateRecommendation();

}


/* =========================================================
   AI RECOMMENDATION
========================================================= */

function updateRecommendation() {

    let title =
        "Balanced Modern Interior";


    let description =
        "Your design combines practical furniture, coordinated colors, suitable lighting and an efficient room layout.";


    const style =
        String(
            roomData.style ||
            ""
        ).toLowerCase();


    if (
        style.includes(
            "luxury"
        )
    ) {

        title =
            "Premium Luxury Interior";


        description =
            "The design focuses on elegant furniture, refined colors, decorative lighting and a sophisticated room arrangement.";

    }


    else if (
        style.includes(
            "minimal"
        )
    ) {

        title =
            "Clean Minimal Interior";


        description =
            "The design emphasizes simple furniture, open space, controlled colors and functional lighting.";

    }


    else if (
        style.includes(
            "japanese"
        )
    ) {

        title =
            "Japanese-Inspired Interior";


        description =
            "The design emphasizes calm colors, natural materials, simple furniture and an uncluttered layout.";

    }


    else if (
        style.includes(
            "scandinavian"
        )
    ) {

        title =
            "Scandinavian Interior";


        description =
            "The design combines functional furniture, bright colors, natural textures and comfortable lighting.";

    }


    setText(
        "finalRecommendation",

        title
    );


    setText(
        "finalRecommendationText",

        description
    );

}


/* =========================================================
   INITIALIZE BUTTONS
========================================================= */

function initializeButtons() {

    const downloadButton =
        document.getElementById(
            "downloadButton"
        );


    const printButton =
        document.getElementById(
            "printButton"
        );


    const newDesignButton =
        document.getElementById(
            "newDesignButton"
        );


    if (downloadButton) {

        downloadButton.addEventListener(
            "click",
            downloadSummary
        );

    }


    if (printButton) {

        printButton.addEventListener(
            "click",
            () => {

                window.print();

            }
        );

    }


    if (newDesignButton) {

        newDesignButton.addEventListener(
            "click",
            startNewDesign
        );

    }

}


/* =========================================================
   DOWNLOAD SUMMARY
========================================================= */

function downloadSummary() {

    const summary = `

AI ROOM DESIGNER
=============================

FINAL ROOM DESIGN SUMMARY

Room Type:
${roomData.roomType}

AI Design Style:
${formatStyle(roomData.style)}

Room Dimensions:
${roomData.length} × ${roomData.breadth} × ${roomData.height} ft

Room Area:
${roomData.area} sq.ft


BUDGET
=============================

Budget Level:
${formatBudgetLevel(budgetData.level)}

Estimated Project Cost:
${formatINR(Number(budgetData.total || 0))}

Cost Per Sq.Ft:
${formatINR(
    roomData.area > 0
        ? Number(budgetData.total || 0) /
          roomData.area
        : 0
)}


AI RECOMMENDATION
=============================

${document.getElementById(
    "finalRecommendation"
).textContent}

${document.getElementById(
    "finalRecommendationText"
).textContent}


DESIGN MODULES
=============================

✓ Room Analysis
✓ Furniture Planning
✓ Color Selection
✓ Blueprint
✓ Lighting Plan
✓ Budget Calculation


AI ROOM DESIGNER
TYCS MINI PROJECT

`;



    const blob =
        new Blob(
            [summary],
            {
                type:
                    "text/plain"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href =
        url;


    link.download =
        "AI-Room-Designer-Summary.txt";


    document.body.appendChild(
        link
    );


    link.click();


    document.body.removeChild(
        link
    );


    URL.revokeObjectURL(
        url
    );

}


/* =========================================================
   START NEW DESIGN
========================================================= */

function startNewDesign() {

    const confirmReset =
        window.confirm(
            "Start a new room design? Current saved room and budget data will be cleared."
        );


    if (!confirmReset) {

        return;

    }


    localStorage.removeItem(
        "aiRoomData"
    );


    localStorage.removeItem(
        "aiBudgetData"
    );


    localStorage.removeItem(
        "aiFurnitureData"
    );


    localStorage.removeItem(
        "aiColorData"
    );


    localStorage.removeItem(
        "aiBlueprintData"
    );


    localStorage.removeItem(
        "aiLightingData"
    );


    window.location.href =
        "../index.html";

}


/* =========================================================
   FORMAT INDIAN RUPEES
========================================================= */

function formatINR(
    amount
) {

    return new Intl.NumberFormat(
        "en-IN",
        {

            style: "currency",

            currency: "INR",

            maximumFractionDigits: 0

        }
    ).format(
        amount
    );

}


/* =========================================================
   FORMAT BUDGET LEVEL
========================================================= */

function formatBudgetLevel(
    level
) {

    if (!level) {

        return "STANDARD";

    }


    return String(
        level
    ).toUpperCase();

}


/* =========================================================
   FORMAT STYLE
========================================================= */

function formatStyle(
    style
) {

    if (!style) {

        return "Modern";

    }


    return String(
        style
    )
    .replace(
        /[-_]/g,
        " "
    )
    .replace(
        /\b\w/g,
        character =>
            character.toUpperCase()
    );

}


/* =========================================================
   TEXT HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}