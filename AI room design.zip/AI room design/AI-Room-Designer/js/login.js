
const loginForm = document.getElementById("loginForm");
const loginStatus = document.getElementById("loginStatus");

loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (!email || !password) {
        loginStatus.textContent = "Please enter your email and password.";
        return;
    }

    loginStatus.textContent =
        "Login page is working. Account verification will be connected to the backend later.";
});
