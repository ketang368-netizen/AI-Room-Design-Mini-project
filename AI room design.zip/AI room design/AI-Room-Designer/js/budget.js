/* =========================================================
   AI ROOM DESIGNER
   BUDGET MODULE
========================================================= */


/* =========================================================
   ROOM DATA
========================================================= */

let roomData = {

    roomType: "Living Room",

    length: 12,

    breadth: 10,

    height: 10,

    area: 120

};


/* =========================================================
   BUDGET DATA
========================================================= */

let budgetData = {

    level: "standard",

    furniture: 0,

    lighting: 0,

    decor: 0,

    painting: 0,

    labour: 0,

    contingency: 0,

    total: 0

};


/* =========================================================
   BUDGET RATES
========================================================= */

/*
   These are simplified project estimates.

   They are NOT vendor quotations.

   The rates are intentionally kept as
   approximate planning values for the
   TYCS mini-project.
*/

const budgetRates = {

    basic: {

        furniture: 500,

        lighting: 120,

        decor: 100,

        painting: 80,

        labour: 150

    },


    standard: {

        furniture: 800,

        lighting: 180,

        decor: 180,

        painting: 120,

        labour: 220

    },


    premium: {

        furniture: 1200,

        lighting: 300,

        decor: 300,

        painting: 180,

        labour: 320

    }

};


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Budget module initialized."
        );


        loadRoomData();

        loadBudgetData();

        updateRoomInformation();

        initializeBudgetOptions();

        calculateBudget();

        updateRecommendation();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const savedData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedData) {

        return;

    }


    try {

        const data =
            JSON.parse(
                savedData
            );


        roomData = {

            ...roomData,

            ...data

        };


        roomData.length =
            Number(
                data.length ||
                data.roomLength ||
                roomData.length
            );


        roomData.breadth =
            Number(
                data.breadth ||
                data.roomBreadth ||
                roomData.breadth
            );


        roomData.height =
            Number(
                data.height ||
                data.roomHeight ||
                roomData.height
            );


        roomData.area =
            roomData.length *
            roomData.breadth;


    } catch (error) {

        console.error(
            "Unable to load room data:",
            error
        );

    }

}


/* =========================================================
   LOAD BUDGET DATA
========================================================= */

function loadBudgetData() {

    const savedData =
        localStorage.getItem(
            "aiBudgetData"
        );


    if (!savedData) {

        return;

    }


    try {

        budgetData = {

            ...budgetData,

            ...JSON.parse(
                savedData
            )

        };

    } catch (error) {

        console.error(
            "Unable to load budget data:",
            error
        );

    }

}


/* =========================================================
   ROOM INFORMATION
========================================================= */

function updateRoomInformation() {

    setText(
        "roomType",
        roomData.roomType ||
        "Room"
    );


    const area =
        roomData.length *
        roomData.breadth;


    roomData.area =
        area;


    setText(
        "roomArea",
        area.toFixed(2)
    );


    setText(
        "roomDimensions",

        `${roomData.length} × ${roomData.breadth} ft`
    );

}


/* =========================================================
   INITIALIZE BUDGET OPTIONS
========================================================= */

function initializeBudgetOptions() {

    const options =
        document.querySelectorAll(
            ".budget-option"
        );


    options.forEach(
        option => {

            option.classList.toggle(
                "active",
                option.dataset.level ===
                budgetData.level
            );


            option.addEventListener(
                "click",
                () => {

                    budgetData.level =
                        option.dataset.level;


                    options.forEach(
                        item => {

                            item.classList.remove(
                                "active"
                            );

                        }
                    );


                    option.classList.add(
                        "active"
                    );


                    calculateBudget();

                    updateRecommendation();

                    saveBudgetData();

                }
            );

        }
    );

}


/* =========================================================
   CALCULATE BUDGET
========================================================= */

function calculateBudget() {

    const area =
        roomData.area;


    const rates =
        budgetRates[
            budgetData.level
        ];


    if (!rates) {

        return;

    }


    /*
       Individual costs
    */

    budgetData.furniture =
        area *
        rates.furniture;


    budgetData.lighting =
        area *
        rates.lighting;


    budgetData.decor =
        area *
        rates.decor;


    budgetData.painting =
        area *
        rates.painting;


    budgetData.labour =
        area *
        rates.labour;


    /*
       Subtotal
    */

    const subtotal =
        budgetData.furniture +
        budgetData.lighting +
        budgetData.decor +
        budgetData.painting +
        budgetData.labour;


    /*
       5% contingency
    */

    budgetData.contingency =
        subtotal *
        0.05;


    /*
       Total
    */

    budgetData.total =
        subtotal +
        budgetData.contingency;


    /*
       Update screen
    */

    setText(
        "furnitureCost",
        formatINR(
            budgetData.furniture
        )
    );


    setText(
        "lightingCost",
        formatINR(
            budgetData.lighting
        )
    );


    setText(
        "decorCost",
        formatINR(
            budgetData.decor
        )
    );


    setText(
        "paintingCost",
        formatINR(
            budgetData.painting
        )
    );


    setText(
        "labourCost",
        formatINR(
            budgetData.labour
        )
    );


    setText(
        "contingencyCost",
        formatINR(
            budgetData.contingency
        )
    );


    setText(
        "totalCost",
        formatINR(
            budgetData.total
        )
    );


    setText(
        "costPerSqft",

        formatINR(
            budgetData.total /
            area
        )

    );

}


/* =========================================================
   AI RECOMMENDATION
========================================================= */

function updateRecommendation() {

    let title =
        "Standard Budget Recommended";


    let text =
        "The standard budget provides a balanced combination of quality, appearance and cost.";


    let score =
        90;


    if (
        budgetData.level ===
        "basic"
    ) {

        title =
            "Basic Budget Recommended";


        text =
            "The basic option focuses on essential furniture, practical lighting and simple finishes. It is suitable when keeping the overall project cost low is the priority.";


        score =
            82;

    }


    else if (
        budgetData.level ===
        "standard"
    ) {

        title =
            "Standard Budget Recommended";


        text =
            "The standard option gives a good balance between furniture quality, lighting, decorative elements and overall project cost.";


        score =
            94;

    }


    else if (
        budgetData.level ===
        "premium"
    ) {

        title =
            "Premium Budget Selected";


        text =
            "The premium option allows better furniture, enhanced lighting, higher-quality finishes and additional decorative elements.";


        score =
            88;

    }


    setText(
        "recommendationTitle",
        title
    );


    setText(
        "recommendationText",
        text
    );


    setText(
        "budgetScore",
        score
    );

}


/* =========================================================
   FORMAT INDIAN RUPEES
========================================================= */

function formatINR(
    amount
) {

    return new Intl.NumberFormat(
        "en-IN",
        {

            style: "currency",

            currency: "INR",

            maximumFractionDigits: 0

        }
    ).format(
        amount
    );

}


/* =========================================================
   SAVE BUDGET DATA
========================================================= */

function saveBudgetData() {

    localStorage.setItem(
        "aiBudgetData",
        JSON.stringify(
            budgetData
        )
    );

}


/* =========================================================
   TEXT HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   DEBUG ACCESS
========================================================= */

window.AIRoomBudget = {

    roomData,

    budgetData,

    calculateBudget,

    updateRecommendation

};