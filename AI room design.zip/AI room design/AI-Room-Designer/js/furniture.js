/* =========================================================
   AI ROOM DESIGNER
   FURNITURE MODULE
========================================================= */


/* =========================================================
   PROJECT STATE
========================================================= */

const furnitureState = {

    selected: [],

    totalCost: 0

};


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Furniture module initialized."
        );


        loadRoomData();

        initializeFilters();

        initializeFurnitureButtons();

        updateSelectedFurniture();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const savedData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedData) {

        console.log(
            "No room data found."
        );

        return;

    }


    try {

        const data =
            JSON.parse(
                savedData
            );


        setText(
            "roomType",
            data.roomType ||
            "Not available"
        );


        setText(
            "roomArea",
            formatNumber(data.area)
        );


        setText(
            "roomStyle",
            capitalize(
                data.style ||
                "modern"
            )
        );


        calculateAvailableSpace(
            data
        );


    } catch (error) {

        console.error(
            "Room data error:",
            error
        );

    }

}


/* =========================================================
   AVAILABLE SPACE
========================================================= */

function calculateAvailableSpace(
    data
) {

    const area =
        Number(data.area) || 0;


    let available;


    /*
       We reserve approximately 35%
       of floor area for movement.
    */

    available =
        area * 0.65;


    setText(
        "availableSpace",
        `${available.toFixed(1)} sq.ft`
    );

}


/* =========================================================
   FILTER SYSTEM
========================================================= */

function initializeFilters() {

    const buttons =
        document.querySelectorAll(
            ".filter-button"
        );


    const cards =
        document.querySelectorAll(
            ".furniture-card"
        );


    buttons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    buttons.forEach(
                        item =>
                            item.classList.remove(
                                "active"
                            )
                    );


                    button.classList.add(
                        "active"
                    );


                    const category =
                        button.dataset.category;


                    cards.forEach(
                        card => {

                            if (
                                category ===
                                "all"
                            ) {

                                card.style.display =
                                    "";

                                return;

                            }


                            if (
                                card.dataset.category ===
                                category
                            ) {

                                card.style.display =
                                    "";

                            } else {

                                card.style.display =
                                    "none";

                            }

                        }
                    );

                }
            );

        }
    );

}


/* =========================================================
   ADD / REMOVE FURNITURE
========================================================= */

function initializeFurnitureButtons() {

    const buttons =
        document.querySelectorAll(
            ".add-furniture"
        );


    buttons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    const name =
                        button.dataset.name;


                    const price =
                        Number(
                            button.dataset.price
                        );


                    const card =
                        button.closest(
                            ".furniture-card"
                        );


                    const id =
                        card.dataset.id;


                    const existing =
                        furnitureState.selected.find(
                            item =>
                                item.id === id
                        );


                    if (existing) {

                        removeFurniture(
                            id
                        );

                        return;

                    }


                    furnitureState.selected.push({

                        id,

                        name,

                        price

                    });


                    card.classList.add(
                        "selected"
                    );


                    button.textContent =
                        "− REMOVE";


                    updateSelectedFurniture();

                }
            );

        }
    );

}


/* =========================================================
   REMOVE FURNITURE
========================================================= */

function removeFurniture(
    id
) {

    furnitureState.selected =
        furnitureState.selected.filter(
            item =>
                item.id !== id
        );


    const card =
        document.querySelector(
            `.furniture-card[data-id="${id}"]`
        );


    if (card) {

        card.classList.remove(
            "selected"
        );


        const button =
            card.querySelector(
                ".add-furniture"
            );


        if (button) {

            button.textContent =
                "+ ADD";

        }

    }


    updateSelectedFurniture();

}


/* =========================================================
   UPDATE SELECTED PANEL
========================================================= */

function updateSelectedFurniture() {

    const panel =
        document.getElementById(
            "selectedPanel"
        );


    const totalCostElement =
        document.getElementById(
            "totalCost"
        );


    const itemCountElement =
        document.getElementById(
            "itemCount"
        );


    if (!panel) {

        return;

    }


    furnitureState.totalCost =
        furnitureState.selected.reduce(
            (
                total,
                item
            ) =>
                total + item.price,
            0
        );


    setText(
        "totalCost",
        formatCurrency(
            furnitureState.totalCost
        )
    );


    setText(
        "itemCount",
        furnitureState.selected.length
    );


    if (
        furnitureState.selected.length ===
        0
    ) {

        panel.innerHTML = `

            <div class="empty-selected">

                <div>
                    +
                </div>

                <p>
                    No furniture selected yet.
                </p>

            </div>

        `;

        saveFurnitureData();

        return;

    }


    panel.innerHTML =
        furnitureState.selected
            .map(
                item => `

                    <div
                        class="selected-item"
                    >

                        <span
                            class="selected-item-name"
                        >
                            ${item.name}
                        </span>


                        <span
                            class="selected-item-price"
                        >
                            ₹${formatCurrency(item.price)}
                        </span>


                        <button
                            class="remove-item"
                            data-id="${item.id}"
                        >
                            REMOVE
                        </button>

                    </div>

                `
            )
            .join("");


    const removeButtons =
        panel.querySelectorAll(
            ".remove-item"
        );


    removeButtons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    removeFurniture(
                        button.dataset.id
                    );

                }
            );

        }
    );


    saveFurnitureData();

}


/* =========================================================
   SAVE FURNITURE DATA
========================================================= */

function saveFurnitureData() {

    localStorage.setItem(
        "aiFurnitureData",
        JSON.stringify(
            furnitureState
        )
    );

}


/* =========================================================
   HELPERS
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


function formatNumber(
    value
) {

    const number =
        Number(value);


    if (!Number.isFinite(number)) {

        return "0";

    }


    return number.toFixed(2);

}


function formatCurrency(
    value
) {

    return Number(value).toLocaleString(
        "en-IN"
    );

}


function capitalize(
    value
) {

    if (!value) {

        return "";

    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


/* =========================================================
   DEBUG ACCESS
========================================================= */

window.AIRoomFurniture = {

    furnitureState,

    updateSelectedFurniture,

    removeFurniture

};