/* =========================================================
   AI ROOM DESIGNER
   BLUEPRINT MODULE
========================================================= */


/* =========================================================
   GLOBAL DATA
========================================================= */

let roomData = {

    length: 12,

    breadth: 10,

    height: 10,

    area: 120,

    roomType: "Living Room"

};


let colorData = {

    palette: "modern",

    wall: "#F4F4F0",

    floor: "#D9D9D2",

    furniture: "#263238",

    accent: "#29D8FF"

};


let zoomLevel = 1;


/* =========================================================
   PAGE LOAD
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        console.log(
            "Blueprint module initialized."
        );


        loadRoomData();

        loadColorData();

        updateRoomInformation();

        generateBlueprint();

        initializeControls();

    }
);


/* =========================================================
   LOAD ROOM DATA
========================================================= */

function loadRoomData() {

    const savedRoomData =
        localStorage.getItem(
            "aiRoomData"
        );


    if (!savedRoomData) {

        console.log(
            "No saved room data found. Using demo dimensions."
        );

        return;

    }


    try {

        const data =
            JSON.parse(
                savedRoomData
            );


        roomData = {

            ...roomData,

            ...data

        };


        roomData.length =
            Number(
                data.length ||
                data.roomLength ||
                roomData.length
            );


        roomData.breadth =
            Number(
                data.breadth ||
                data.roomBreadth ||
                roomData.breadth
            );


        roomData.height =
            Number(
                data.height ||
                data.roomHeight ||
                roomData.height
            );


        roomData.area =
            Number(
                data.area ||
                roomData.length *
                roomData.breadth
            );


    } catch (error) {

        console.error(
            "Room data error:",
            error
        );

    }

}


/* =========================================================
   LOAD COLOR DATA
========================================================= */

function loadColorData() {

    const savedColorData =
        localStorage.getItem(
            "aiColorData"
        );


    if (!savedColorData) {

        return;

    }


    try {

        const data =
            JSON.parse(
                savedColorData
            );


        colorData = {

            ...colorData,

            ...data

        };


    } catch (error) {

        console.error(
            "Color data error:",
            error
        );

    }

}


/* =========================================================
   UPDATE ROOM INFORMATION
========================================================= */

function updateRoomInformation() {

    setText(
        "roomType",
        roomData.roomType ||
        "Room"
    );


    setText(
        "roomLength",
        roomData.length.toFixed(2)
    );


    setText(
        "roomBreadth",
        roomData.breadth.toFixed(2)
    );


    setText(
        "roomHeight",
        roomData.height.toFixed(2)
    );


    const area =
        roomData.length *
        roomData.breadth;


    roomData.area = area;


    setText(
        "roomArea",
        area.toFixed(2)
    );


    setText(
        "summaryArea",
        area.toFixed(2) +
        " sq.ft"
    );


    const perimeter =
        2 *
        (
            roomData.length +
            roomData.breadth
        );


    setText(
        "summaryPerimeter",
        perimeter.toFixed(2) +
        " ft"
    );


    setText(
        "designTitle",
        (
            roomData.roomType ||
            "Room"
        ) +
        " Blueprint"
    );


    setText(
        "designDescription",
        "Technical floor plan generated from " +
        roomData.length.toFixed(2) +
        " × " +
        roomData.breadth.toFixed(2) +
        " ft room dimensions."
    );

}


/* =========================================================
   GENERATE BLUEPRINT
========================================================= */

function generateBlueprint() {

    const svg =
        document.getElementById(
            "blueprintSvg"
        );


    if (!svg) {

        return;

    }


    svg.innerHTML = "";


    /*
       SVG working area
    */

    const svgWidth = 1000;

    const svgHeight = 650;


    /*
       Keep room inside canvas
    */

    const maxRoomWidth = 680;

    const maxRoomHeight = 420;


    const scaleX =
        maxRoomWidth /
        roomData.length;


    const scaleY =
        maxRoomHeight /
        roomData.breadth;


    const scale =
        Math.min(
            scaleX,
            scaleY
        );


    const roomWidth =
        roomData.length *
        scale;


    const roomHeight =
        roomData.breadth *
        scale;


    const roomX =
        (
            svgWidth -
            roomWidth
        ) / 2;


    const roomY =
        (
            svgHeight -
            roomHeight
        ) / 2;


    /*
       Grid
    */

    drawGrid(
        svg,
        svgWidth,
        svgHeight
    );


    /*
       Room
    */

    drawRoom(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );


    /*
       Door
    */

    drawDoor(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );


    /*
       Window
    */

    drawWindow(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );


    /*
       Furniture
    */

    drawFurniture(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );


    /*
       Dimensions
    */

    drawDimensions(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );


    /*
       Center label
    */

    drawRoomLabel(
        svg,
        roomX,
        roomY,
        roomWidth,
        roomHeight
    );

}


/* =========================================================
   GRID
========================================================= */

function drawGrid(
    svg,
    width,
    height
) {

    const group =
        createSvgElement(
            "g"
        );


    group.setAttribute(
        "id",
        "blueprintGrid"
    );


    const spacing = 25;


    for (
        let x = 0;
        x <= width;
        x += spacing
    ) {

        const line =
            createSvgElement(
                "line"
            );


        line.setAttribute(
            "x1",
            x
        );

        line.setAttribute(
            "y1",
            0
        );

        line.setAttribute(
            "x2",
            x
        );

        line.setAttribute(
            "y2",
            height
        );


        line.setAttribute(
            "stroke",
            "rgba(41,216,255,.12)"
        );


        line.setAttribute(
            "stroke-width",
            "1"
        );


        group.appendChild(
            line
        );

    }


    for (
        let y = 0;
        y <= height;
        y += spacing
    ) {

        const line =
            createSvgElement(
                "line"
            );


        line.setAttribute(
            "x1",
            0
        );

        line.setAttribute(
            "y1",
            y
        );

        line.setAttribute(
            "x2",
            width
        );

        line.setAttribute(
            "y2",
            y
        );


        line.setAttribute(
            "stroke",
            "rgba(41,216,255,.12)"
        );


        line.setAttribute(
            "stroke-width",
            "1"
        );


        group.appendChild(
            line
        );

    }


    svg.appendChild(
        group
    );

}


/* =========================================================
   ROOM
========================================================= */

function drawRoom(
    svg,
    x,
    y,
    width,
    height
) {

    const room =
        createSvgElement(
            "rect"
        );


    room.setAttribute(
        "x",
        x
    );

    room.setAttribute(
        "y",
        y
    );

    room.setAttribute(
        "width",
        width
    );

    room.setAttribute(
        "height",
        height
    );


    room.setAttribute(
        "class",
        "blueprint-room"
    );


    svg.appendChild(
        room
    );


    /*
       Inner wall
    */

    const inner =
        createSvgElement(
            "rect"
        );


    inner.setAttribute(
        "x",
        x + 12
    );

    inner.setAttribute(
        "y",
        y + 12
    );

    inner.setAttribute(
        "width",
        width - 24
    );

    inner.setAttribute(
        "height",
        height - 24
    );


    inner.setAttribute(
        "class",
        "blueprint-inner"
    );


    svg.appendChild(
        inner
    );

}


/* =========================================================
   DOOR
========================================================= */

function drawDoor(
    svg,
    x,
    y,
    width,
    height
) {

    /*
       Door placed at bottom wall
    */

    const doorWidth = 80;


    const doorX =
        x +
        width / 2 -
        doorWidth / 2;


    const doorY =
        y +
        height -
        6;


    const door =
        createSvgElement(
            "line"
        );


    door.setAttribute(
        "x1",
        doorX
    );

    door.setAttribute(
        "y1",
        doorY
    );

    door.setAttribute(
        "x2",
        doorX +
        doorWidth
    );

    door.setAttribute(
        "y2",
        doorY
    );


    door.setAttribute(
        "class",
        "blueprint-door"
    );


    svg.appendChild(
        door
    );


    /*
       Door swing
    */

    const swing =
        createSvgElement(
            "path"
        );


    const radius =
        doorWidth;


    const startX =
        doorX;


    const startY =
        doorY;


    const endX =
        doorX +
        doorWidth;


    const endY =
        doorY;


    swing.setAttribute(
        "d",
        `M ${startX} ${startY}
         A ${radius} ${radius}
         0 0 1 ${endX} ${endY}`
    );


    swing.setAttribute(
        "fill",
        "none"
    );


    swing.setAttribute(
        "stroke",
        "#7895aa"
    );


    swing.setAttribute(
        "stroke-width",
        "1.5"
    );


    svg.appendChild(
        swing
    );

}


/* =========================================================
   WINDOW
========================================================= */

function drawWindow(
    svg,
    x,
    y,
    width,
    height
) {

    const windowWidth =
        Math.min(
            150,
            width * .25
        );


    const windowX =
        x +
        width / 2 -
        windowWidth / 2;


    const windowY =
        y -
        3;


    const windowLine =
        createSvgElement(
            "line"
        );


    windowLine.setAttribute(
        "x1",
        windowX
    );

    windowLine.setAttribute(
        "y1",
        windowY
    );

    windowLine.setAttribute(
        "x2",
        windowX +
        windowWidth
    );

    windowLine.setAttribute(
        "y2",
        windowY
    );


    windowLine.setAttribute(
        "class",
        "blueprint-window"
    );


    svg.appendChild(
        windowLine
    );


    /*
       Window divisions
    */

    const divider =
        createSvgElement(
            "line"
        );


    divider.setAttribute(
        "x1",
        windowX +
        windowWidth / 2
    );

    divider.setAttribute(
        "y1",
        windowY
    );

    divider.setAttribute(
        "x2",
        windowX +
        windowWidth / 2
    );

    divider.setAttribute(
        "y2",
        windowY + 12
    );


    divider.setAttribute(
        "stroke",
        "#7895aa"
    );


    divider.setAttribute(
        "stroke-width",
        "2"
    );


    svg.appendChild(
        divider
    );

}


/* =========================================================
   FURNITURE
========================================================= */

function drawFurniture(
    svg,
    x,
    y,
    width,
    height
) {

    const group =
        createSvgElement(
            "g"
        );


    group.setAttribute(
        "id",
        "furnitureLayer"
    );


    /*
       Sofa
    */

    const sofaWidth =
        Math.min(
            180,
            width * .3
        );


    const sofaHeight = 65;


    const sofaX =
        x +
        width / 2 -
        sofaWidth / 2;


    const sofaY =
        y +
        height * .22;


    drawFurnitureRect(
        group,
        sofaX,
        sofaY,
        sofaWidth,
        sofaHeight,
        "SOFA"
    );


    /*
       Coffee table
    */

    const tableWidth = 100;

    const tableHeight = 55;


    const tableX =
        x +
        width / 2 -
        tableWidth / 2;


    const tableY =
        y +
        height * .55;


    drawFurnitureRect(
        group,
        tableX,
        tableY,
        tableWidth,
        tableHeight,
        "TABLE"
    );


    /*
       TV / cabinet
    */

    const cabinetWidth =
        Math.min(
            170,
            width * .28
        );


    const cabinetHeight = 35;


    const cabinetX =
        x +
        width / 2 -
        cabinetWidth / 2;


    const cabinetY =
        y +
        height -
        80;


    drawFurnitureRect(
        group,
        cabinetX,
        cabinetY,
        cabinetWidth,
        cabinetHeight,
        "TV"
    );


    svg.appendChild(
        group
    );

}


/* =========================================================
   FURNITURE RECTANGLE
========================================================= */

function drawFurnitureRect(
    group,
    x,
    y,
    width,
    height,
    label
) {

    const rect =
        createSvgElement(
            "rect"
        );


    rect.setAttribute(
        "x",
        x
    );

    rect.setAttribute(
        "y",
        y
    );

    rect.setAttribute(
        "width",
        width
    );

    rect.setAttribute(
        "height",
        height
    );


    rect.setAttribute(
        "class",
        "blueprint-furniture"
    );


    group.appendChild(
        rect
    );


    const text =
        createSvgElement(
            "text"
        );


    text.setAttribute(
        "x",
        x +
        width / 2
    );

    text.setAttribute(
        "y",
        y +
        height / 2 +
        4
    );


    text.setAttribute(
        "text-anchor",
        "middle"
    );


    text.setAttribute(
        "class",
        "blueprint-small-text"
    );


    text.textContent =
        label;


    group.appendChild(
        text
    );

}


/* =========================================================
   DIMENSIONS
========================================================= */

function drawDimensions(
    svg,
    x,
    y,
    width,
    height
) {

    const dimensionLayer =
        createSvgElement(
            "g"
        );


    dimensionLayer.setAttribute(
        "id",
        "dimensionLayer"
    );


    /*
       Horizontal dimension
    */

    const horizontalY =
        y +
        height +
        55;


    drawDimensionLine(
        dimensionLayer,
        x,
        horizontalY,
        x + width,
        horizontalY,
        roomData.length.toFixed(2) +
        " ft"
    );


    /*
       Vertical dimension
    */

    const verticalX =
        x -
        55;


    drawDimensionLine(
        dimensionLayer,
        verticalX,
        y,
        verticalX,
        y + height,
        roomData.breadth.toFixed(2) +
        " ft"
    );


    svg.appendChild(
        dimensionLayer
    );

}


/* =========================================================
   DIMENSION LINE
========================================================= */

function drawDimensionLine(
    group,
    x1,
    y1,
    x2,
    y2,
    label
) {

    const line =
        createSvgElement(
            "line"
        );


    line.setAttribute(
        "x1",
        x1
    );

    line.setAttribute(
        "y1",
        y1
    );

    line.setAttribute(
        "x2",
        x2
    );

    line.setAttribute(
        "y2",
        y2
    );


    line.setAttribute(
        "class",
        "blueprint-dimension"
    );


    group.appendChild(
        line
    );


    /*
       Label
    */

    const text =
        createSvgElement(
            "text"
        );


    text.setAttribute(
        "x",
        (x1 + x2) / 2
    );


    text.setAttribute(
        "y",
        (y1 + y2) / 2 - 8
    );


    text.setAttribute(
        "text-anchor",
        "middle"
    );


    text.setAttribute(
        "class",
        "blueprint-text"
    );


    text.textContent =
        label;


    group.appendChild(
        text
    );

}


/* =========================================================
   ROOM LABEL
========================================================= */

function drawRoomLabel(
    svg,
    x,
    y,
    width,
    height
) {

    const text =
        createSvgElement(
            "text"
        );


    text.setAttribute(
        "x",
        x +
        width / 2
    );


    text.setAttribute(
        "y",
        y +
        height -
        25
    );


    text.setAttribute(
        "text-anchor",
        "middle"
    );


    text.setAttribute(
        "class",
        "blueprint-small-text"
    );


    text.textContent =
        (
            roomData.roomType ||
            "ROOM"
        ).toUpperCase();


    svg.appendChild(
        text
    );

}


/* =========================================================
   CONTROLS
========================================================= */

function initializeControls() {

    const gridToggle =
        document.getElementById(
            "gridToggle"
        );


    const dimensionToggle =
        document.getElementById(
            "dimensionToggle"
        );


    const furnitureToggle =
        document.getElementById(
            "furnitureToggle"
        );


    const zoomIn =
        document.getElementById(
            "zoomIn"
        );


    const zoomOut =
        document.getElementById(
            "zoomOut"
        );


    if (gridToggle) {

        gridToggle.addEventListener(
            "click",
            () => {

                toggleLayer(
                    "blueprintGrid",
                    gridToggle
                );

            }
        );

    }


    if (dimensionToggle) {

        dimensionToggle.addEventListener(
            "click",
            () => {

                toggleLayer(
                    "dimensionLayer",
                    dimensionToggle
                );

            }
        );

    }


    if (furnitureToggle) {

        furnitureToggle.addEventListener(
            "click",
            () => {

                toggleLayer(
                    "furnitureLayer",
                    furnitureToggle
                );

            }
        );

    }


    if (zoomIn) {

        zoomIn.addEventListener(
            "click",
            () => {

                changeZoom(
                    .1
                );

            }
        );

    }


    if (zoomOut) {

        zoomOut.addEventListener(
            "click",
            () => {

                changeZoom(
                    -.1
                );

            }
        );

    }

}


/* =========================================================
   TOGGLE LAYER
========================================================= */

function toggleLayer(
    layerId,
    button
) {

    const layer =
        document.getElementById(
            layerId
        );


    if (!layer) {

        return;

    }


    const hidden =
        layer.style.display ===
        "none";


    layer.style.display =
        hidden
            ? ""
            : "none";


    button.classList.toggle(
        "active",
        hidden
    );

}


/* =========================================================
   ZOOM
========================================================= */

function changeZoom(
    amount
) {

    zoomLevel += amount;


    zoomLevel =
        Math.min(
            1.5,
            Math.max(
                .7,
                zoomLevel
            )
        );


    const svg =
        document.getElementById(
            "blueprintSvg"
        );


    if (svg) {

        svg.style.transform =
            `scale(${zoomLevel})`;

    }


    setText(
        "zoomValue",
        Math.round(
            zoomLevel * 100
        ) +
        "%"
    );

}


/* =========================================================
   SVG HELPER
========================================================= */

function createSvgElement(
    tag
) {

    return document.createElementNS(
        "http://www.w3.org/2000/svg",
        tag
    );

}


/* =========================================================
   TEXT HELPER
========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


/* =========================================================
   DEBUG ACCESS
========================================================= */

window.AIRoomBlueprint = {

    generateBlueprint,

    roomData,

    colorData

};