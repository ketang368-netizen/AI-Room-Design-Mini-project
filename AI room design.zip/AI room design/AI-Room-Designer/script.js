/* =========================================================
   AI ROOM DESIGNER
   BLUEPRINT EDITION
   MAIN JAVASCRIPT
========================================================= */


/* =========================================================
   1. WAIT FOR PAGE TO LOAD
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    console.log("AI Room Designer initialized.");

    initializeUpload();
    initializeDimensions();
    initializeStyleSelector();
    initializeDesignGenerator();
    initializeMobileMenu();
    initializeNavigation();

});


/* =========================================================
   2. GLOBAL PROJECT STATE
========================================================= */

const roomData = {

    image: null,

    style: "modern",

    length: 0,

    breadth: 0,

    height: 0,

    area: 0,

    volume: 0,

    roomType: "Not calculated",

    aiStatus: "Ready"

};


/* =========================================================
   3. IMAGE UPLOAD
========================================================= */

function initializeUpload() {

    const uploadArea =
        document.getElementById("uploadArea");

    const uploadButton =
        document.getElementById("uploadButton");

    const roomImage =
        document.getElementById("roomImage");

    const imagePreview =
        document.getElementById("imagePreview");

    const previewImage =
        document.getElementById("previewImage");

    const removeImage =
        document.getElementById("removeImage");


    if (
        !uploadArea ||
        !uploadButton ||
        !roomImage
    ) {

        console.warn("Upload elements not found.");

        return;

    }


    /* -----------------------------------------
       Choose Image Button
    ------------------------------------------ */

    uploadButton.addEventListener("click", () => {

        roomImage.click();

    });


    /* -----------------------------------------
       Click Upload Area
    ------------------------------------------ */

    uploadArea.addEventListener("click", (event) => {

        if (
            event.target === uploadButton ||
            event.target.closest("#uploadButton")
        ) {

            return;

        }

        roomImage.click();

    });


    /* -----------------------------------------
       File Selected
    ------------------------------------------ */

    roomImage.addEventListener("change", (event) => {

        const file =
            event.target.files[0];

        if (!file) {

            return;

        }

        handleImageUpload(file);

    });


    /* -----------------------------------------
       Remove Image
    ------------------------------------------ */

    if (removeImage) {

        removeImage.addEventListener("click", () => {

            roomImage.value = "";

            roomData.image = null;

            if (imagePreview) {

                imagePreview.hidden = true;

            }

            if (previewImage) {

                previewImage.src = "";

            }

            setAIStatus(
                "Ready",
                0
            );

        });

    }


    /* -----------------------------------------
       Drag & Drop
    ------------------------------------------ */

    uploadArea.addEventListener(
        "dragover",
        (event) => {

            event.preventDefault();

            uploadArea.classList.add(
                "drag-over"
            );

        }
    );


    uploadArea.addEventListener(
        "dragleave",
        () => {

            uploadArea.classList.remove(
                "drag-over"
            );

        }
    );


    uploadArea.addEventListener(
        "drop",
        (event) => {

            event.preventDefault();

            uploadArea.classList.remove(
                "drag-over"
            );

            const file =
                event.dataTransfer.files[0];

            if (!file) {

                return;

            }

            if (!file.type.startsWith("image/")) {

                showMessage(
                    "Please upload an image file.",
                    "error"
                );

                return;

            }

            handleImageUpload(file);

        }
    );


    /* -----------------------------------------
       Image Upload Handler
    ------------------------------------------ */

    function handleImageUpload(file) {

        if (!file.type.startsWith("image/")) {

            showMessage(
                "Please select a valid image.",
                "error"
            );

            return;

        }


        const maxSize =
            10 * 1024 * 1024;


        if (file.size > maxSize) {

            showMessage(
                "Image size must be less than 10 MB.",
                "error"
            );

            return;

        }


        roomData.image = file;


        const reader =
            new FileReader();


        reader.onload = (readerEvent) => {

            if (previewImage) {

                previewImage.src =
                    readerEvent.target.result;

            }

            if (imagePreview) {

                imagePreview.hidden = false;

            }


            setAIStatus(
                "Image Ready",
                20
            );


            console.log(
                "Room image uploaded:",
                file.name
            );

        };


        reader.readAsDataURL(file);

    }

}


/* =========================================================
   4. STYLE SELECTOR
========================================================= */

function initializeStyleSelector() {

    const styleOptions =
        document.querySelectorAll(
            'input[name="roomStyle"]'
        );


    styleOptions.forEach((option) => {

        option.addEventListener(
            "change",
            () => {

                if (!option.checked) {

                    return;

                }


                roomData.style =
                    option.value;


                console.log(
                    "Selected style:",
                    roomData.style
                );


                setAIStatus(
                    "Style Selected",
                    30
                );


                updateAnalysisPreview();

            }
        );

    });

}


/* =========================================================
   5. ROOM DIMENSIONS
========================================================= */

function initializeDimensions() {

    const calculateButton =
        document.getElementById(
            "calculateRoom"
        );


    if (!calculateButton) {

        return;

    }


    calculateButton.addEventListener(
        "click",
        calculateRoom
    );


    /* -----------------------------------------
       Enter Key Support
    ------------------------------------------ */

    const dimensionInputs = [

        document.getElementById("roomLength"),

        document.getElementById("roomBreadth"),

        document.getElementById("roomHeight")

    ];


    dimensionInputs.forEach((input) => {

        if (!input) {

            return;

        }


        input.addEventListener(
            "keydown",
            (event) => {

                if (event.key === "Enter") {

                    calculateRoom();

                }

            }
        );

    });

}


/* =========================================================
   6. CALCULATE ROOM
========================================================= */

function calculateRoom() {

    const lengthInput =
        document.getElementById(
            "roomLength"
        );

    const breadthInput =
        document.getElementById(
            "roomBreadth"
        );

    const heightInput =
        document.getElementById(
            "roomHeight"
        );


    if (
        !lengthInput ||
        !breadthInput ||
        !heightInput
    ) {

        return;

    }


    const length =
        parseFloat(lengthInput.value);

    const breadth =
        parseFloat(breadthInput.value);

    const height =
        parseFloat(heightInput.value);


    /* -----------------------------------------
       Validate Inputs
    ------------------------------------------ */

    if (
        !Number.isFinite(length) ||
        !Number.isFinite(breadth) ||
        !Number.isFinite(height)
    ) {

        showMessage(
            "Please enter Length, Breadth and Height.",
            "error"
        );

        return;

    }


    if (
        length <= 0 ||
        breadth <= 0 ||
        height <= 0
    ) {

        showMessage(
            "Room dimensions must be greater than zero.",
            "error"
        );

        return;

    }


    /* -----------------------------------------
       Calculate Area and Volume
    ------------------------------------------ */

    const area =
        length * breadth;


    const volume =
        length * breadth * height;


    const roomType =
        determineRoomType(
            area,
            length,
            breadth
        );


   /* -----------------------------------------
   Save Data
------------------------------------------ */

roomData.length =
    length;

roomData.breadth =
    breadth;

roomData.height =
    height;

roomData.area =
    area;

roomData.volume =
    volume;

roomData.roomType =
    roomType;


/* -----------------------------------------
   Save Room Data
------------------------------------------ */

localStorage.setItem(
    "aiRoomData",
    JSON.stringify(roomData)
);

    /* -----------------------------------------
       Display Result
    ------------------------------------------ */

    const roomResult =
        document.getElementById(
            "roomResult"
        );


    const roomArea =
        document.getElementById(
            "roomArea"
        );


    const roomVolume =
        document.getElementById(
            "roomVolume"
        );


    const roomTypeElement =
        document.getElementById(
            "roomType"
        );


    if (roomResult) {

        roomResult.hidden = false;

    }


    if (roomArea) {

        roomArea.textContent =
            area.toFixed(2);

    }


    if (roomVolume) {

        roomVolume.textContent =
            volume.toFixed(2);

    }


    if (roomTypeElement) {

        roomTypeElement.textContent =
            roomType;

    }


    /* -----------------------------------------
       Update Blueprint
    ------------------------------------------ */

    updateBlueprint();


    /* -----------------------------------------
       Update Status
    ------------------------------------------ */

    setAIStatus(
        "Room Calculated",
        50
    );


    updateAnalysisPreview();


    showMessage(
        "Room dimensions calculated successfully.",
        "success"
    );


    console.log(
        "Room data:",
        roomData
    );

}


/* =========================================================
   7. DETERMINE ROOM TYPE
========================================================= */

function determineRoomType(
    area,
    length,
    breadth
) {

    const smallest =
        Math.min(
            length,
            breadth
        );


    if (area < 80) {

        return "Small Room";

    }


    if (area < 150) {

        return "Medium Room";

    }


    if (area < 250) {

        return "Large Room";

    }


    return "Spacious Room";

}


/* =========================================================
   8. UPDATE BLUEPRINT
========================================================= */

function updateBlueprint() {

    const areaElement =
        document.getElementById(
            "blueprintArea"
        );

    const lengthElement =
        document.getElementById(
            "blueprintLength"
        );

    const breadthElement =
        document.getElementById(
            "blueprintBreadth"
        );


    if (roomData.area > 0) {

        if (areaElement) {

            areaElement.textContent =
                `${roomData.area.toFixed(2)} sq.ft`;

        }

        if (lengthElement) {

            lengthElement.textContent =
                `${roomData.length} ft`;

        }

        if (breadthElement) {

            breadthElement.textContent =
                `${roomData.breadth} ft`;

        }


        /* -------------------------------------
           Update Blueprint Dimension Labels
        -------------------------------------- */

        const topDimension =
            document.querySelector(
                ".bp-top span"
            );


        const sideDimension =
            document.querySelector(
                ".bp-side span"
            );


        if (topDimension) {

            topDimension.textContent =
                `${roomData.length} ft`;

        }


        if (sideDimension) {

            sideDimension.textContent =
                `${roomData.breadth} ft`;

        }

    }

}


/* =========================================================
   9. AI ANALYSIS PREVIEW
========================================================= */

function updateAnalysisPreview() {

    const analysisContent =
        document.getElementById(
            "analysisContent"
        );


    if (!analysisContent) {

        return;

    }


    const styleName =
        capitalize(
            roomData.style
        );


    if (
        roomData.area > 0
    ) {

        analysisContent.innerHTML = `

            <div class="analysis-result">

                <div class="analysis-result-item">

                    <span>STYLE</span>

                    <strong>
                        ${styleName}
                    </strong>

                </div>


                <div class="analysis-result-item">

                    <span>ROOM</span>

                    <strong>
                        ${roomData.roomType}
                    </strong>

                </div>


                <div class="analysis-result-item">

                    <span>AREA</span>

                    <strong>
                        ${roomData.area.toFixed(2)} sq.ft
                    </strong>

                </div>


                <div class="analysis-result-item">

                    <span>HEIGHT</span>

                    <strong>
                        ${roomData.height} ft
                    </strong>

                </div>


                <div class="analysis-message">

                    AI has prepared the room data
                    for ${styleName} style planning.

                </div>

            </div>

        `;

    }

}


/* =========================================================
   10. GENERATE DESIGN
========================================================= */

function initializeDesignGenerator() {

    const generateButton =
        document.getElementById(
            "generateDesign"
        );


    if (!generateButton) {

        return;

    }


    generateButton.addEventListener(
        "click",
        generateDesign
    );

}


/* =========================================================
   11. AI DESIGN SIMULATION
========================================================= */

async function generateDesign() {

    /* -----------------------------------------
       Basic Validation
    ------------------------------------------ */

    if (!roomData.image) {

        showMessage(
            "Please upload a room image first.",
            "error"
        );

        document
            .getElementById("uploadArea")
            ?.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        return;

    }


    if (
        roomData.length <= 0 ||
        roomData.breadth <= 0 ||
        roomData.height <= 0
    ) {

        showMessage(
            "Please calculate your room dimensions first.",
            "error"
        );

        document
            .getElementById("roomLength")
            ?.focus();

        return;

    }


    /* -----------------------------------------
       Start AI Simulation
    ------------------------------------------ */

    const generateButton =
        document.getElementById(
            "generateDesign"
        );


    if (generateButton) {

        generateButton.disabled = true;

        generateButton.textContent =
            "⟳ AI Designing...";

    }


    try {

        await runAISimulation();


        createFinalAnalysis();


        setAIStatus(
            "Design Complete",
            100
        );


        showMessage(
            "AI room design generated successfully.",
            "success"
        );


    } catch (error) {

        console.error(
            "Design generation error:",
            error
        );


        setAIStatus(
            "Error",
            0
        );


        showMessage(
            "Something went wrong while generating the design.",
            "error"
        );


    } finally {

        if (generateButton) {

            generateButton.disabled = false;

            generateButton.textContent =
                "✦ Generate AI Design";

        }

    }

}


/* =========================================================
   12. AI SIMULATION
========================================================= */

async function runAISimulation() {

    const steps = [

        {
            text: "Analyzing room image...",
            progress: 55,
            delay: 900
        },

        {
            text: "Processing room dimensions...",
            progress: 65,
            delay: 800
        },

        {
            text: "Selecting furniture layout...",
            progress: 75,
            delay: 900
        },

        {
            text: "Generating color recommendations...",
            progress: 85,
            delay: 800
        },

        {
            text: "Preparing blueprint...",
            progress: 95,
            delay: 900
        }

    ];


    for (const step of steps) {

        setAIStatus(
            step.text,
            step.progress
        );

        await delay(
            step.delay
        );

    }

}


/* =========================================================
   13. FINAL AI ANALYSIS
========================================================= */

function createFinalAnalysis() {

    const analysisContent =
        document.getElementById(
            "analysisContent"
        );


    if (!analysisContent) {

        return;

    }


    const style =
        capitalize(
            roomData.style
        );


    const recommendations =
        getStyleRecommendations(
            roomData.style
        );


    analysisContent.innerHTML = `

        <div class="final-analysis">

            <div class="analysis-success">

                <span class="analysis-check">
                    ✓
                </span>

                <div>

                    <strong>
                        Room Analysis Complete
                    </strong>

                    <p>
                        AI design simulation completed.
                    </p>

                </div>

            </div>


            <div class="analysis-details">

                <div class="analysis-detail">

                    <span>
                        SELECTED STYLE
                    </span>

                    <strong>
                        ${style}
                    </strong>

                </div>


                <div class="analysis-detail">

                    <span>
                        ROOM TYPE
                    </span>

                    <strong>
                        ${roomData.roomType}
                    </strong>

                </div>


                <div class="analysis-detail">

                    <span>
                        ROOM AREA
                    </span>

                    <strong>
                        ${roomData.area.toFixed(2)} sq.ft
                    </strong>

                </div>

            </div>


            <div class="recommendations">

                <h4>
                    AI Recommendations
                </h4>

                <ul>

                    ${recommendations
                        .map(
                            item =>
                                `<li>${item}</li>`
                        )
                        .join("")
                    }

                </ul>

            </div>

        </div>

    `;


    /* -----------------------------------------
       Add temporary styles dynamically
    ------------------------------------------ */

    addAnalysisStyles();

}


/* =========================================================
   14. STYLE RECOMMENDATIONS
========================================================= */

function getStyleRecommendations(
    style
) {

    const recommendations = {

        modern: [

            "Use clean furniture lines with minimal decoration.",

            "Consider neutral walls with a strong accent element.",

            "Use layered LED lighting for a contemporary appearance."

        ],


        luxury: [

            "Use elegant furniture with premium-looking finishes.",

            "Add warm accent lighting and decorative elements.",

            "Use a balanced combination of neutral and rich tones."

        ],


        minimal: [

            "Keep furniture limited to essential pieces.",

            "Use a simple neutral color palette.",

            "Maintain open walking space around the furniture."

        ],


        japanese: [

            "Prefer natural materials and simple furniture.",

            "Use calm neutral tones inspired by nature.",

            "Keep the room uncluttered with open visual space."

        ],


        scandinavian: [

            "Use light colors and comfortable functional furniture.",

            "Add natural textures and simple decorative elements.",

            "Maximize natural light wherever possible."

        ]

    };


    return (
        recommendations[style] ||
        recommendations.modern
    );

}


/* =========================================================
   15. AI STATUS
========================================================= */

function setAIStatus(
    status,
    progress
) {

    roomData.aiStatus =
        status;


    const statusText =
        document.getElementById(
            "aiStatus"
        );


    const progressBar =
        document.getElementById(
            "statusProgress"
        );


    const statusDot =
        document.getElementById(
            "statusDot"
        );


    if (statusText) {

        statusText.textContent =
            status;

    }


    if (progressBar) {

        progressBar.style.width =
            `${progress}%`;

    }


    if (statusDot) {

        if (status === "Error") {

            statusDot.style.background =
                "var(--danger)";

            statusDot.style.boxShadow =
                "0 0 10px rgba(255, 100, 124, 0.7)";

        } else if (
            status === "Design Complete"
        ) {

            statusDot.style.background =
                "var(--success)";

            statusDot.style.boxShadow =
                "0 0 10px rgba(56, 232, 155, 0.7)";

        } else {

            statusDot.style.background =
                "var(--cyan)";

            statusDot.style.boxShadow =
                "0 0 10px rgba(41, 216, 255, 0.7)";

        }

    }

}


/* =========================================================
   16. MOBILE MENU
========================================================= */

function initializeMobileMenu() {

    const menuToggle =
        document.getElementById(
            "menuToggle"
        );


    const navbar =
        document.querySelector(
            ".navbar"
        );


    if (
        !menuToggle ||
        !navbar
    ) {

        return;

    }


    menuToggle.addEventListener(
        "click",
        () => {

            navbar.classList.toggle(
                "show"
            );

        }
    );


    /* -----------------------------------------
       Close menu after clicking link
    ------------------------------------------ */

    const links =
        navbar.querySelectorAll(
            ".nav-link"
        );


    links.forEach((link) => {

        link.addEventListener(
            "click",
            () => {

                navbar.classList.remove(
                    "show"
                );

            }
        );

    });

}


/* =========================================================
   17. NAVIGATION
========================================================= */

function initializeNavigation() {

    const navLinks =
        document.querySelectorAll(
            ".nav-link"
        );


    navLinks.forEach((link) => {

        link.addEventListener(
            "click",
            () => {

                navLinks.forEach(
                    item =>
                        item.classList.remove(
                            "active"
                        )
                );


                link.classList.add(
                    "active"
                );

            }
        );

    });

}


/* =========================================================
   18. MESSAGE SYSTEM
========================================================= */

function showMessage(
    message,
    type = "info"
) {

    const existing =
        document.querySelector(
            ".site-message"
        );


    if (existing) {

        existing.remove();

    }


    const messageElement =
        document.createElement(
            "div"
        );


    messageElement.className =
        `site-message ${type}`;


    messageElement.textContent =
        message;


    document.body.appendChild(
        messageElement
    );


    requestAnimationFrame(() => {

        messageElement.classList.add(
            "show"
        );

    });


    setTimeout(() => {

        messageElement.classList.remove(
            "show"
        );


        setTimeout(() => {

            messageElement.remove();

        }, 300);

    }, 3000);


    addMessageStyles();

}


/* =========================================================
   19. ANALYSIS EXTRA STYLES
========================================================= */

function addAnalysisStyles() {

    if (
        document.getElementById(
            "analysisDynamicStyles"
        )
    ) {

        return;

    }


    const style =
        document.createElement(
            "style"
        );


    style.id =
        "analysisDynamicStyles";


    style.textContent = `

        .final-analysis {

            width: 100%;

        }


        .analysis-success {

            display: flex;

            align-items: center;

            gap: 12px;

            padding: 14px;

            border:
                1px solid
                rgba(56, 232, 155, 0.25);

            background:
                rgba(56, 232, 155, 0.05);

            margin-bottom: 15px;

        }


        .analysis-check {

            width: 35px;

            height: 35px;

            display: grid;

            place-items: center;

            border-radius: 50%;

            color:
                var(--success);

            border:
                1px solid
                rgba(56, 232, 155, 0.4);

        }


        .analysis-success strong {

            color:
                var(--white);

            font-size: 13px;

        }


        .analysis-success p {

            color:
                var(--muted);

            font-size: 10px;

        }


        .analysis-details {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 8px;

            margin-bottom: 15px;

        }


        .analysis-detail {

            padding: 10px;

            border:
                1px solid
                var(--border);

            background:
                rgba(41, 216, 255, 0.03);

        }


        .analysis-detail span {

            display: block;

            color:
                var(--muted);

            font-size: 8px;

            margin-bottom: 3px;

        }


        .analysis-detail strong {

            color:
                var(--cyan);

            font-size: 11px;

        }


        .recommendations {

            border-top:
                1px solid
                var(--border);

            padding-top: 13px;

        }


        .recommendations h4 {

            color:
                var(--white);

            font-size: 12px;

            margin-bottom: 8px;

        }


        .recommendations ul {

            padding-left: 16px;

        }


        .recommendations li {

            color:
                var(--muted);

            font-size: 10px;

            margin-bottom: 5px;

        }

    `;


    document.head.appendChild(
        style
    );

}


/* =========================================================
   20. MESSAGE STYLES
========================================================= */

function addMessageStyles() {

    if (
        document.getElementById(
            "messageDynamicStyles"
        )
    ) {

        return;

    }


    const style =
        document.createElement(
            "style"
        );


    style.id =
        "messageDynamicStyles";


    style.textContent = `

        .site-message {

            position: fixed;

            top: 90px;

            right: 20px;

            z-index: 9999;

            max-width: 340px;

            padding: 13px 18px;

            border:
                1px solid
                var(--border);

            color:
                var(--text);

            background:
                rgba(7, 26, 46, 0.97);

            box-shadow:
                0 10px 35px
                rgba(0, 0, 0, 0.35);

            font-size: 12px;

            transform:
                translateX(120%);

            opacity: 0;

            transition:
                transform 0.3s ease,
                opacity 0.3s ease;

        }


        .site-message.show {

            transform:
                translateX(0);

            opacity: 1;

        }


        .site-message.success {

            border-color:
                rgba(56, 232, 155, 0.45);

        }


        .site-message.error {

            border-color:
                rgba(255, 100, 124, 0.5);

        }

    `;


    document.head.appendChild(
        style
    );

}


/* =========================================================
   21. UTILITY FUNCTIONS
========================================================= */

function capitalize(value) {

    if (!value) {

        return "";

    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


function delay(milliseconds) {

    return new Promise(
        resolve =>
            setTimeout(
                resolve,
                milliseconds
            )
    );

}


/* =========================================================
   22. DEBUG HELPER
========================================================= */

window.AIRoomDesigner = {

    roomData,

    calculateRoom,

    updateBlueprint,

    generateDesign,

    setAIStatus

};


/* =========================================================
   CONNECT ROOM IMAGE UPLOAD TO BACKEND
========================================================= */

const roomImageInput = document.querySelector(
    'input[type="file"]'
);


if (roomImageInput) {

    roomImageInput.addEventListener(
        "change",
        async function () {

            const file =
                this.files[0];


            if (!file) {

                return;

            }


            /*
               Check file type
            */

            const allowedTypes = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];


            if (
                !allowedTypes.includes(
                    file.type
                )
            ) {

                alert(
                    "Please select a JPG, PNG or WEBP image."
                );

                this.value = "";

                return;

            }


            /*
               Check file size
            */

            if (
                file.size >
                5 * 1024 * 1024
            ) {

                alert(
                    "Image must be smaller than 5 MB."
                );

                this.value = "";

                return;

            }


            /*
               Show image preview
            */

            const reader =
                new FileReader();


            reader.onload = function (event) {

                const preview =
                    document.querySelector(
                        "#previewImage"
                    );


                if (preview) {

                    preview.src =
                        event.target.result;

                    preview.style.display =
                        "block";

                }

            };


            reader.readAsDataURL(file);


            /*
               Upload image to backend
            */

            const result =
                await uploadRoomImage(file);


            if (result && result.success) {

                console.log(
                    "Upload successful:",
                    result.file
                );

            }

        }
    );

}
/* =========================================================
   STEP 2 — CALCULATE ROOM USING BACKEND
========================================================= */

async function calculateRoomFromInputs() {

    const lengthInput =
        document.getElementById("roomLength");

    const breadthInput =
        document.getElementById("roomBreadth");

    const heightInput =
        document.getElementById("roomHeight");


    if (
        !lengthInput ||
        !breadthInput ||
        !heightInput
    ) {

        console.error(
            "Room dimension inputs not found."
        );

        return;

    }


    const length =
        Number(lengthInput.value);

    const breadth =
        Number(breadthInput.value);

    const height =
        Number(heightInput.value);


    /* Validate values */

    if (
        !length ||
        !breadth ||
        !height ||
        length <= 0 ||
        breadth <= 0 ||
        height <= 0
    ) {

        alert(
            "Please enter valid Length, Breadth and Height."
        );

        return;

    }


    try {

        const response =
            await fetch(
                "/api/room/calculate",
                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        length: length,

                        breadth: breadth,

                        height: height

                    })

                }
            );


        const result =
            await response.json();


        if (!response.ok) {

            throw new Error(
                result.message ||
                "Room calculation failed."
            );

        }


        console.log(
            "Room calculation result:",
            result
        );


        /* -----------------------------------------
           Save result
        ------------------------------------------ */

        if (typeof roomData !== "undefined") {

            roomData.length =
                result.room.length;

            roomData.breadth =
                result.room.breadth;

            roomData.height =
                result.room.height;

            roomData.area =
                result.room.area;

            roomData.volume =
                result.room.volume;


            localStorage.setItem(
                "aiRoomData",
                JSON.stringify(
                    roomData
                )
            );

        }


        /* -----------------------------------------
           Display result
        ------------------------------------------ */

        displayRoomCalculation(
            result.room
        );


    }

    catch (error) {

        console.error(
            "Room calculation error:",
            error
        );

        alert(
            "Unable to calculate room: " +
            error.message
        );

    }

}


/* =========================================================
   DISPLAY ROOM RESULT
========================================================= */

function displayRoomCalculation(room) {

    /*
       Look for an existing result area.
    */

    const resultPanel =
        document.querySelector(
            ".room-result"
        );


    if (!resultPanel) {

        console.log(
            "Room calculated successfully:",
            room
        );

        return;

    }


    resultPanel.innerHTML = `

        <div class="result-item">

            <span>
                Length
            </span>

            <strong>
                ${room.length} ft
            </strong>

        </div>


        <div class="result-item">

            <span>
                Breadth
            </span>

            <strong>
                ${room.breadth} ft
            </strong>

        </div>


        <div class="result-item">

            <span>
                Height
            </span>

            <strong>
                ${room.height} ft
            </strong>

        </div>


        <div class="result-item">

            <span>
                Floor Area
            </span>

            <strong>
                ${room.area.toFixed(2)} sq.ft
            </strong>

        </div>


        <div class="result-item">

            <span>
                Room Volume
            </span>

            <strong>
                ${room.volume.toFixed(2)} cubic ft
            </strong>

        </div>

    `;

}
/* =========================================================
   CONNECT CALCULATE ROOM BUTTON
========================================================= */

const calculateRoomButton =
    document.getElementById("calculateRoom");


if (calculateRoomButton) {

    calculateRoomButton.addEventListener(
        "click",
        calculateRoomFromInputs
    );

}
/* =========================================================
   ROOM IMAGE UPLOAD FUNCTION
========================================================= */

async function uploadRoomImage(file) {

    if (!file) {
        return null;
    }

    const formData = new FormData();

    formData.append("roomImage", file);

    try {

        const response = await fetch(
            "/api/upload",
            {
                method: "POST",
                body: formData
            }
        );

        const result = await response.json();

        if (!response.ok) {

            throw new Error(
                result.message ||
                "Image upload failed."
            );

        }

        console.log(
            "Room image uploaded:",
            result
        );

        localStorage.setItem(
            "uploadedRoomImage",
            JSON.stringify(result.file)
        );

        return result;

    } catch (error) {

        console.error(
            "Upload error:",
            error
        );

        alert(
            "Room image upload failed: " +
            error.message
        );

        return null;
    }
}
/* =========================================================
   STEP 4 — AI STYLE SIMULATION
========================================================= */

const aiStyleProfiles = {

    modern: {

        name: "Modern",

        description:
            "A clean contemporary room with practical furniture and balanced colors.",

        colors: [
            "White",
            "Grey",
            "Charcoal",
            "Natural Wood"
        ],

        furniture: [
            "Modern Sofa",
            "TV Unit",
            "Coffee Table",
            "Storage Cabinet"
        ],

        lighting: [
            "LED Ceiling Lights",
            "Wall Lights",
            "Accent Lighting"
        ]

    },


    luxury: {

        name: "Luxury",

        description:
            "An elegant room using premium-looking furniture, rich colors and decorative lighting.",

        colors: [
            "Cream",
            "Beige",
            "Gold",
            "Deep Brown"
        ],

        furniture: [
            "Premium Sofa",
            "Designer Coffee Table",
            "Luxury TV Unit",
            "Decorative Cabinet"
        ],

        lighting: [
            "Chandelier",
            "Warm Ceiling Lights",
            "Decorative Accent Lights"
        ]

    },


    minimal: {

        name: "Minimal",

        description:
            "A simple and uncluttered room focused on functionality and open space.",

        colors: [
            "White",
            "Light Grey",
            "Beige",
            "Soft Brown"
        ],

        furniture: [
            "Simple Sofa",
            "Compact Table",
            "Wall Storage",
            "Minimal TV Unit"
        ],

        lighting: [
            "Recessed LED Lights",
            "Soft Ceiling Lights",
            "Natural Light"
        ]

    },


    japanese: {

        name: "Japanese",

        description:
            "A calm interior inspired by Japanese simplicity, natural materials and balanced spaces.",

        colors: [
            "Warm White",
            "Beige",
            "Natural Wood",
            "Soft Brown"
        ],

        furniture: [
            "Low Sofa",
            "Low Coffee Table",
            "Wooden Storage",
            "Floor Seating"
        ],

        lighting: [
            "Warm Ambient Lights",
            "Paper-Style Lamps",
            "Natural Window Light"
        ]

    },


    scandinavian: {

        name: "Scandinavian",

        description:
            "A bright and comfortable interior using simple furniture and natural materials.",

        colors: [
            "White",
            "Light Grey",
            "Soft Beige",
            "Light Wood"
        ],

        furniture: [
            "Fabric Sofa",
            "Wooden Coffee Table",
            "Open Shelf",
            "Simple TV Unit"
        ],

        lighting: [
            "Pendant Lights",
            "Warm LED Lights",
            "Natural Light"
        ]

    }

};