const express = require("express");
const path = require("path");
const multer = require("multer");
const fs = require("fs");

const app = express();

const PORT = 3000;


/* =========================================================
   UPLOAD FOLDER
========================================================= */

const uploadDirectory = path.join(
    __dirname,
    "uploads"
);


/*
   Create uploads folder if it doesn't exist.
*/

if (!fs.existsSync(uploadDirectory)) {

    fs.mkdirSync(
        uploadDirectory,
        {
            recursive: true
        }
    );

}


/* =========================================================
   MULTER STORAGE
========================================================= */

const storage = multer.diskStorage({

    destination: function (req, file, cb) {

        cb(
            null,
            uploadDirectory
        );

    },

    filename: function (req, file, cb) {

        const extension =
            path.extname(
                file.originalname
            );

        const fileName =
            `room-${Date.now()}${extension}`;

        cb(
            null,
            fileName
        );

    }

});


/* =========================================================
   IMAGE FILTER
========================================================= */

const imageFilter = function (
    req,
    file,
    cb
) {

    const allowedTypes = [

        "image/jpeg",

        "image/png",

        "image/webp"

    ];


    if (
        allowedTypes.includes(
            file.mimetype
        )
    ) {

        cb(
            null,
            true
        );

    }

    else {

        cb(
            new Error(
                "Only JPG, PNG and WEBP images are allowed."
            )
        );

    }

};


/* =========================================================
   UPLOAD CONFIGURATION
========================================================= */

const upload = multer({

    storage: storage,

    fileFilter: imageFilter,

    limits: {

        fileSize:
            5 * 1024 * 1024

    }

});


/* =========================================================
   MIDDLEWARE
========================================================= */

app.use(
    express.json()
);


app.use(
    express.urlencoded({
        extended: true
    })
);


/* =========================================================
   STATIC FILES
========================================================= */

app.use(
    express.static(
        __dirname
    )
);


/* =========================================================
   HOME PAGE
========================================================= */

app.get(
    "/",
    (req, res) => {

        res.sendFile(
            path.join(
                __dirname,
                "index.html"
            )
        );

    }
);


/* =========================================================
   API STATUS
========================================================= */

app.get(
    "/api/status",
    (req, res) => {

        res.json({

            success: true,

            message:
                "AI Room Designer backend is running.",

            server:
                "Node.js + Express",

            status:
                "online"

        });

    }
);


/* =========================================================
   IMAGE UPLOAD API
========================================================= */

app.post(
    "/api/upload",
    upload.single("roomImage"),
    (req, res) => {

        /*
           Check whether a file was received.
        */

        if (!req.file) {

            return res.status(400).json({

                success: false,

                message:
                    "Please select a room image."

            });

        }


        /*
           Return information about
           the uploaded image.
        */

        res.json({

            success: true,

            message:
                "Room image uploaded successfully.",

            file: {

                originalName:
                    req.file.originalname,

                fileName:
                    req.file.filename,

                size:
                    req.file.size,

                path:
                    `/uploads/${req.file.filename}`

            }

        });

    }
);


/* =========================================================
   ROOM CALCULATION API
========================================================= */

app.post(
    "/api/room/calculate",
    (req, res) => {

        const length =
            Number(
                req.body.length
            );

        const breadth =
            Number(
                req.body.breadth
            );

        const height =
            Number(
                req.body.height
            );


        /*
           Validate dimensions.
        */

        if (
            !length ||
            !breadth ||
            !height ||
            length <= 0 ||
            breadth <= 0 ||
            height <= 0
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Please provide valid room dimensions."

            });

        }


        /*
           Floor area.
        */

        const area =
            length *
            breadth;


        /*
           Room volume.
        */

        const volume =
            length *
            breadth *
            height;


        res.json({

            success: true,

            room: {

                length:
                    length,

                breadth:
                    breadth,

                height:
                    height,

                area:
                    area,

                volume:
                    volume

            }

        });

    }
);


/* =========================================================
   UPLOAD ERROR HANDLER
========================================================= */

app.use(
    (err, req, res, next) => {

        if (
            err instanceof
            multer.MulterError
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Image upload failed. Maximum file size is 5 MB."

            });

        }


        if (err) {

            return res.status(400).json({

                success: false,

                message:
                    err.message

            });

        }


        next();

    }
);


/* =========================================================
   404 HANDLER
========================================================= */

app.use(
    (req, res) => {

        res.status(404).json({

            success: false,

            message:
                "Page or API endpoint not found."

        });

    }
);


/* =========================================================
   START SERVER
========================================================= */

app.listen(
    PORT,
    () => {

        console.log("");

        console.log(
            "=========================================="
        );

        console.log(
            "       AI ROOM DESIGNER SERVER"
        );

        console.log(
            "=========================================="
        );

        console.log(
            `Server running at: http://localhost:${PORT}`
        );

        console.log(
            `API status: http://localhost:${PORT}/api/status`
        );

        console.log(
            `Upload API: http://localhost:${PORT}/api/upload`
        );

        console.log(
            "=========================================="
        );

        console.log("");

    }
);